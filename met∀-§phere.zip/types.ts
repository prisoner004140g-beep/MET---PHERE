

export enum TransactionType {
  INCOME = 'income',
  EXPENSE = 'expense',
}

export interface Transaction {
  id: number;
  description: string;
  amount: number;
  type: TransactionType;
  date: string;
}

export enum ContactType {
  PERSON = 'Person',
  BUSINESS = 'Business',
}

export interface Coordinates {
    latitude: number;
    longitude: number;
}

export interface Persona {
    id: number;
    name: string;
    title: string;
    description: string;
}

export interface Contact {
  id: number;
  name: string;
  notes: string;
  contactType: ContactType;
  location?: string;
  coordinates?: Coordinates;
  hobbies?: string;
  skills?: string;
  knowledge?: string;
  debts?: string;
  credits?: string;
  tags?: string; // comma-separated
  personas?: Persona[];
  language?: string; // comma-separated
}

export enum Sphere {
  ULTRAVIOLET = 'Ultraviolet (Finance)',
  INFRARED = 'Infrared (Interactions)',
  WHITE = 'White (Learning)',
  BLACK = 'Black (Thoughts)',
  RED = 'Red (Land Navigation)',
  BLUE = 'Blue (Air Navigation)',
  YELLOW = 'Yellow (Sea Navigation)',
}

export enum RelationshipType {
  NETWORKING = 'Networking',
  FRIENDSHIP = 'Friendship',
  ASSOCIATE = 'Associate',
  CONFLICT = 'Conflict',
}

export interface Relationship {
  id: number;
  sourceId: number;
  targetId: number;
  description: string;
  sphere: Sphere;
  relationshipType: RelationshipType;
}

export enum KnowledgeEntryType {
    GENERAL = 'General',
    MANIFESTO = 'Manifesto',
    VISION = 'Vision',
    LINGUISTICS = 'Linguistics',
    TUTORIAL = 'Tutorial',
    TASK = 'Task',
}

export enum ManifestoType {
    SHADOW = 'Shadow Manifesto',
    OLD_WORLD = 'Old World Manifesto',
    NEW_WORLD = 'New World Manifesto',
}

export interface KnowledgeEntry {
    id: number;
    title: string;
    content: string;
    tags: string; // comma-separated
    entryType: KnowledgeEntryType;
    manifestoType?: ManifestoType;
    imageUrl?: string;
    dueDate?: string;
    isCompleted?: boolean;
}

export interface ThoughtEntry {
    id: number;
    content: string;
    mood: string;
    timestamp: string;
    tags?: string; // comma-separated
}

export enum ChatRole {
  USER = 'user',
  AI = 'model',
}

export interface ChatPart {
  text: string;
  grounding?: GroundingChunk[];
}

export interface ChatMessage {
  role: ChatRole;
  parts: ChatPart[];
}

export enum AiModel {
  STANDARD = 'Standard',
  FAST = 'Fast',
  THINKING = 'Thinking',
  LOCATION = 'Location',
}

export interface GroundingChunk {
  maps?: {
    uri: string;
    title: string;
  };
  web?: {
    uri: string;
    title: string;
  };
}

export type AiRole = 'Programmer' | 'God';

export interface Directive {
    title: string;
    description: string; // Situation summary
    sphere: Sphere;
    objective: string; // High-level goal
    rationale: string; // Justification for the directive
    steps: string[]; // Actionable steps
}

export interface Vision {
    id: number;
    url: string;
    prompt: string;
    timestamp: string;
}