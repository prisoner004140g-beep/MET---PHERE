
import { useState, useCallback } from 'react';

interface GeolocationState {
  location: { latitude: number; longitude: number } | null;
  isLoading: boolean;
  error: string | null;
}

export const useGeolocation = (options?: PositionOptions) => {
  const [state, setState] = useState<GeolocationState>({
    location: null,
    isLoading: false,
    error: null,
  });

  const refreshLocation = useCallback(() => {
    return new Promise<{ latitude: number; longitude: number } | null>((resolve, reject) => {
        if (!navigator.geolocation) {
            const errorMsg = 'Geolocation is not supported by your browser.';
            setState(s => ({ ...s, error: errorMsg }));
            reject(errorMsg);
            return;
        }

        setState(s => ({ ...s, isLoading: true, error: null }));
    
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const newLocation = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                };
                setState({
                    location: newLocation,
                    isLoading: false,
                    error: null,
                });
                resolve(newLocation);
            },
            (err) => {
                const fallbackLocation = {
                    latitude: 47.2139,
                    longitude: -65.1508,
                };
                setState({
                    location: fallbackLocation,
                    isLoading: false,
                    error: `Could not get user location, using fallback: Esgenoôpetitj First Nation. Error: ${err.message}`,
                });
                resolve(fallbackLocation); // Resolve with fallback location
            },
            options
        );
    });
  }, [options]);

  return { ...state, refreshLocation };
};