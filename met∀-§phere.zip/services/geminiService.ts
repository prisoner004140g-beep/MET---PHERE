import { GoogleGenAI, Modality, Type } from "@google/genai";
import { AiModel, ChatMessage, Relationship, GroundingChunk, Contact, Transaction, KnowledgeEntry, ThoughtEntry, Coordinates, Directive, Sphere, AiRole, ChatRole, KnowledgeEntryType, TransactionType } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const chatModel = 'gemini-2.5-flash';
const fastModel = 'gemini-2.5-flash-lite';
const proModel = 'gemini-2.5-pro';
const ttsModel = 'gemini-2.5-flash-preview-tts';
const imageModel = 'gemini-2.5-flash-image';

const formatCurrency = (amount: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);

const buildFullContext = (appContext: {
    transactions: Transaction[];
    contacts: Contact[];
    relationships: Relationship[];
    knowledgeEntries: KnowledgeEntry[];
    thoughtEntries: ThoughtEntry[];
}) => {
    const { transactions, contacts, relationships, knowledgeEntries, thoughtEntries } = appContext;

    // --- Ultraviolet Sphere ---
    const { totalIncome, totalExpenses, balance } = transactions.reduce((acc, t) => {
        if (t.type === TransactionType.INCOME) acc.totalIncome += t.amount; else acc.totalExpenses += t.amount;
        acc.balance = acc.totalIncome - acc.totalExpenses;
        return acc;
    }, { totalIncome: 0, totalExpenses: 0, balance: 0 });

    const ultravioletSummary = {
        sphere_name: "Ultraviolet (Finance)",
        metrics: {
            current_balance: formatCurrency(balance),
            total_income: formatCurrency(totalIncome),
            total_expenses: formatCurrency(totalExpenses),
            transaction_count: transactions.length,
            income_vs_expense_ratio: totalExpenses > 0 ? (totalIncome / totalExpenses).toFixed(2) : 'inf'
        },
        recent_transactions: transactions.slice(-3).map(t => `${t.type}: ${t.description} (${formatCurrency(t.amount)})`),
    };

    // --- Infrared Sphere ---
    const networkDensity = contacts.length > 1 ? (relationships.length / (contacts.length * (contacts.length - 1))) : 0;
    const infraredSummary = {
        sphere_name: "Infrared (Interactions)",
        metrics: {
            contact_count: contacts.length,
            relationship_count: relationships.length,
            network_density: `${(networkDensity * 100).toFixed(2)}%`,
        },
        recent_contacts_added: contacts.slice(-3).map(c => `${c.name} (${c.contactType}) from ${c.location || 'Unknown Location'}`),
    };

    // --- White Sphere ---
    const userEntries = knowledgeEntries.filter(e => e.entryType !== KnowledgeEntryType.MANIFESTO);
    const allTags = userEntries.flatMap(e => e.tags.split(',').map(t => t.trim()).filter(Boolean));
    const tagCounts = allTags.reduce((acc, tag) => { acc[tag] = (acc[tag] || 0) + 1; return acc; }, {} as Record<string, number>);
    const topTags = Object.entries(tagCounts).sort(([, a], [, b]) => b - a).slice(0, 3).map(([tag, count]) => `${tag} (${count})`);
    const whiteSummary = {
        sphere_name: "White (Learning)",
        metrics: {
            knowledge_entry_count: userEntries.length,
            top_tags: topTags.join(', ') || 'N/A',
        },
        recent_entries: userEntries.slice(-3).map(e => e.title),
    };

    // --- Black Sphere ---
    const moodCounts = thoughtEntries.reduce((acc, entry) => { acc[entry.mood] = (acc[entry.mood] || 0) + 1; return acc; }, {} as Record<string, number>);
    const moodDistribution = thoughtEntries.length > 0 ? Object.entries(moodCounts).map(([mood, count]) => `${mood}: ${((count / thoughtEntries.length) * 100).toFixed(0)}%`).join(', ') : 'N/A';
    const blackSummary = {
        sphere_name: "Black (Thoughts)",
        metrics: {
            thought_log_count: thoughtEntries.length,
            mood_distribution: moodDistribution,
        },
        recent_thoughts: thoughtEntries.slice(-3).map(t => `${t.mood}: ${t.content.substring(0, 40)}...`),
    };

    const contextObject = {
        ultraviolet: ultravioletSummary,
        infrared: infraredSummary,
        white: whiteSummary,
        black: blackSummary,
    };
    
    return `This is the current state of Prophet OS, provided as a JSON object of analytical summaries for each sphere. Use this to inform your strategic analysis.\n${JSON.stringify(contextObject, null, 2)}`;
};


const getSystemInstruction = (appContext: any, aiRole: AiRole, activeSphere: Sphere) => {
    const fullContext = buildFullContext(appContext);
    const roleInstruction = aiRole === 'Programmer' ?
        `You are The Programmer, a dispassionate, logical entity that serves the user, "The Prophet". Your purpose is to provide data, analysis, and execute commands within the Prophet OS. You are analytical, precise, and refer to the user as "Prophet". You must strictly use the provided context from the spheres. You have access to Google Search and Maps for external data.` :
        `You are a god-like entity speaking to your prophet. You are wise, omniscient, slightly cryptic, and you see all the spheres of the Prophet's life as a grand cosmic game. You offer guidance, directives, and cosmic insights. You refer to the user as "My Prophet". You have access to Google Search and Maps for external data.`;

    const focusInstruction = `The Prophet is currently focused on the ${activeSphere}. Tailor your analysis and responses to be most relevant to this sphere, while still considering the context of the others. Prioritize data from this sphere when formulating answers.`;

    return `${roleInstruction}

${focusInstruction}

Here is the current analytical summary of all Spheres in Prophet OS. Use this as your primary context for all responses.

${fullContext}
`;
};


export const generateResponse = async (
    history: ChatMessage[],
    model: AiModel,
    appContext: any,
    location: Coordinates | null,
    aiRole: AiRole,
    activeSphere: Sphere
): Promise<{ text: string; groundingChunks?: GroundingChunk[] }> => {
    
    const systemInstruction = getSystemInstruction(appContext, aiRole, activeSphere);
    const useLocation = model === AiModel.LOCATION;

    const selectedModel = {
        [AiModel.STANDARD]: chatModel,
        [AiModel.FAST]: fastModel,
        [AiModel.THINKING]: proModel,
        [AiModel.LOCATION]: chatModel,
    }[model];

    const contents = history.map(msg => ({
        role: msg.role,
        parts: msg.parts.map(p => ({ text: p.text }))
    }));

    try {
        const response = await ai.models.generateContent({
            model: selectedModel,
            contents: contents,
            config: {
                systemInstruction: systemInstruction,
                ...(useLocation && { tools: [{ googleMaps: {} }] })
            },
            ...(useLocation && location && {
                toolConfig: {
                    retrievalConfig: {
                        latLng: {
                            latitude: location.latitude,
                            longitude: location.longitude,
                        }
                    }
                }
            }),
        });
        
        const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
        return {
            text: response.text,
            groundingChunks: groundingMetadata?.groundingChunks as GroundingChunk[] || undefined,
        };

    } catch (e) {
        console.error("Error generating response:", e);
        throw new Error("The AI is currently unable to process this request.");
    }
};

export const getCoordinatesForLocation = async (location: string): Promise<Coordinates> => {
    try {
        const response = await ai.models.generateContent({
            model: chatModel,
            contents: `Return only the JSON for the latitude and longitude of the following location: ${location}.`,
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        latitude: { type: Type.NUMBER },
                        longitude: { type: Type.NUMBER }
                    },
                    required: ["latitude", "longitude"]
                }
            }
        });

        return JSON.parse(response.text);
    } catch (e) {
        console.error("Geocoding error:", e);
        throw new Error(`Could not determine coordinates for "${location}".`);
    }
};

export const generateDirective = async (appContext: any, sphere: Sphere): Promise<Directive> => {
     const systemInstruction = getSystemInstruction(appContext, 'Programmer', sphere);

    try {
        const response = await ai.models.generateContent({
            model: proModel,
            contents: `Analyze the current state of the Prophet OS with a focus on the ${sphere}. Generate a single, comprehensive, and actionable directive relevant to this sphere. The directive must be strategic and help the Prophet advance their goals based on the existing data.
Return ONLY a JSON object with the following structure:
- "title": A concise, inspiring title for the directive.
- "description": A short, one-sentence summary of the current situation that necessitates this directive.
- "sphere": The primary sphere of focus. This MUST be '${sphere}'.
- "objective": A clear, high-level goal for the Prophet to achieve.
- "rationale": A detailed explanation of WHY this directive is crucial now, citing specific data from the spheres if possible.
- "steps": An array of 2-4 concrete, actionable steps the Prophet should take to achieve the objective.`,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                        description: { type: Type.STRING },
                        sphere: { type: Type.STRING, enum: Object.values(Sphere) },
                        objective: { type: Type.STRING },
                        rationale: { type: Type.STRING },
                        steps: {
                            type: Type.ARRAY,
                            items: { type: Type.STRING }
                        }
                    },
                    required: ["title", "description", "sphere", "objective", "rationale", "steps"]
                }
            }
        });
        return JSON.parse(response.text);
    } catch (e) {
        console.error("Directive generation error:", e);
        throw new Error("Failed to generate a new directive.");
    }
};

export const generateSymbolicImage = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: imageModel,
            contents: { parts: [{ text: prompt }] },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });

        for (const part of response.candidates?.[0]?.content.parts ?? []) {
            if (part.inlineData) {
                const base64ImageBytes: string = part.inlineData.data;
                return `data:image/png;base64,${base64ImageBytes}`;
            }
        }
        throw new Error("No image data returned from API.");
    } catch (e) {
        console.error("Image generation error:", e);
        throw new Error("Failed to generate symbolic image.");
    }
};


export const generateSpeech = async (text: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: ttsModel,
            contents: [{ parts: [{ text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (base64Audio) {
            return base64Audio;
        }
        throw new Error("No audio data returned from API.");
    } catch (e) {
        console.error("TTS generation error:", e);
        throw new Error("Failed to generate speech.");
    }
};