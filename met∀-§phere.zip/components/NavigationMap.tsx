
import React, { useEffect, useRef } from 'react';
import { Coordinates } from '../types';
import L from 'leaflet';

// Fix for default Leaflet icon path issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

interface MapMarker {
  coords: Coordinates;
  popupText: string;
  isPermanent?: boolean; // To differentiate special markers
}

interface NavigationMapProps {
  center: Coordinates;
  zoom: number;
  markers: MapMarker[];
  tileLayerUrl: string;
  tileLayerOptions?: L.TileLayerOptions;
}

const NavigationMap: React.FC<NavigationMapProps> = ({ center, zoom, markers, tileLayerUrl, tileLayerOptions }) => {
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      mapRef.current = L.map(mapContainerRef.current).setView([center.latitude, center.longitude], zoom);
    } else if (mapRef.current) {
        mapRef.current.setView([center.latitude, center.longitude], zoom);
    }
  }, [center, zoom]);

  useEffect(() => {
    if (mapRef.current) {
        // Clear existing tile layers
        mapRef.current.eachLayer((layer) => {
            if (layer instanceof L.TileLayer) {
                mapRef.current?.removeLayer(layer);
            }
        });
        // Add new tile layer
        L.tileLayer(tileLayerUrl, tileLayerOptions).addTo(mapRef.current);
    }
  }, [tileLayerUrl, tileLayerOptions]);


  useEffect(() => {
    if (mapRef.current) {
      // Clear all markers
      mapRef.current.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
          mapRef.current?.removeLayer(layer);
        }
      });

      // Add new markers
      markers.forEach(marker => {
        const markerInstance = L.marker([marker.coords.latitude, marker.coords.longitude], { isPermanent: marker.isPermanent } as any).addTo(mapRef.current!);
        markerInstance.bindPopup(marker.popupText);
      });
    }
  }, [markers, mapRef.current]);

  return (
    <div ref={mapContainerRef} className="w-full h-full rounded-md" style={{ zIndex: 0 }}></div>
  );
};

export default NavigationMap;
