import React, { useEffect, useRef } from 'react';
import { Coordinates } from '../types';
import { Icons } from './Icons';
import L from 'leaflet';

// Fix for default Leaflet icon path issue with module bundlers
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});


interface MapModalProps {
  center: Coordinates;
  marker: {
    coords: Coordinates;
    popupText: string;
  };
  onClose: () => void;
}

const MapModal: React.FC<MapModalProps> = ({ center, marker, onClose }) => {
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      mapRef.current = L.map(mapContainerRef.current).setView([center.latitude, center.longitude], 13);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(mapRef.current);
    }

    if (mapRef.current) {
        // Clear existing markers
        mapRef.current.eachLayer((layer) => {
            if (layer instanceof L.Marker) {
                mapRef.current?.removeLayer(layer);
            }
        });

        // Add new marker
        const markerInstance = L.marker([marker.coords.latitude, marker.coords.longitude]).addTo(mapRef.current);
        markerInstance.bindPopup(marker.popupText).openPopup();
        mapRef.current.setView([center.latitude, center.longitude], 13);
    }
  }, [center, marker]);

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg shadow-2xl w-11/12 h-5/6 max-w-4xl p-4 flex flex-col border border-purple-500/30 modal-content">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-purple-300">Contact Location: {marker.popupText}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <Icons.close className="w-6 h-6" />
          </button>
        </div>
        <div ref={mapContainerRef} className="flex-grow rounded-md" style={{ zIndex: 0 }}></div>
      </div>
    </div>
  );
};

export default MapModal;