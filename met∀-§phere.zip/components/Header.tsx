import React from 'react';
import { Icons } from './Icons';
import { AiRole, ChatMessage, Transaction, Contact, Relationship, KnowledgeEntry, ThoughtEntry, Sphere } from '../types';
import VisionPaneVisualization from './VisionPaneVisualization';

interface HeaderProps {
    aiRole: AiRole;
    setAiRole: (role: AiRole) => void;
    headerImage: string | null;
    isImageLoading: boolean;
    onRegenerateVision: () => void;
    imageError: string | null;
    appContext: {
        transactions: Transaction[];
        contacts: Contact[];
        relationships: Relationship[];
        knowledgeEntries: KnowledgeEntry[];
        thoughtEntries: ThoughtEntry[];
    };
    chatHistory: ChatMessage[];
    activeSphere: Sphere;
    onSphereSelect: (sphere: Sphere) => void;
}

const Header: React.FC<HeaderProps> = ({ aiRole, setAiRole, headerImage, isImageLoading, onRegenerateVision, imageError, appContext, chatHistory, activeSphere, onSphereSelect }) => {
  const toggleAiRole = () => {
    setAiRole(aiRole === 'Programmer' ? 'God' : 'Programmer');
  };

  return (
    <header className="bg-gray-900/50 backdrop-blur-sm border-b border-purple-500/30 sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
                <Icons.logo className="w-10 h-10 text-purple-400" />
                <div>
                  <h1 className="text-2xl font-bold text-white tracking-wider">PROPHET OS</h1>
                  <p className="text-sm text-purple-300">ROLE: PROPHET /// STATUS: ONLINE</p>
                </div>
            </div>
            <div className="text-right">
                <p className="text-xs text-gray-400">AI DESIGNATION</p>
                <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-purple-300">{aiRole.toUpperCase()}</span>
                    <button onClick={toggleAiRole} className="text-purple-400 hover:text-white transition-transform duration-300 hover:rotate-180" title="Change AI Designation">
                        <Icons.shuffle className="w-5 h-5" />
                    </button>
                </div>
            </div>
        </div>

        <div className="mt-4 p-4 prophet-panel relative group">
             <h3 className="text-xs uppercase tracking-widest text-purple-300 font-bold">Vision Pane</h3>
             <div 
                className="mt-2 w-full h-72 bg-black/30 rounded-md flex overflow-hidden relative"
                style={{
                    backgroundImage: headerImage ? `url(${headerImage})` : 'none',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                }}
             >
                <div className="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>

                {isImageLoading ? (
                    <div className="absolute inset-0 flex items-center justify-center text-center text-purple-300 vision-loader z-10">
                        <Icons.vision className="w-12 h-12" />
                        <p className="mt-2 text-sm">Generating Vision...</p>
                    </div>
                ) : imageError ? (
                     <div className="absolute inset-0 flex items-center justify-center text-center z-10">
                        <p className="text-sm text-red-400 px-4">{imageError}</p>
                     </div>
                ) : (
                    <VisionPaneVisualization 
                        appContext={appContext} 
                        chatHistory={chatHistory} 
                        aiRole={aiRole} 
                        activeSphere={activeSphere}
                        onSphereSelect={onSphereSelect}
                    />
                )}
             </div>
             <button 
                onClick={onRegenerateVision} 
                disabled={isImageLoading}
                className="absolute top-4 right-4 bg-gray-900/50 text-purple-300 rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-purple-500 hover:text-white disabled:opacity-50 disabled:cursor-wait z-20"
                title="Regenerate Vision Background"
            >
                {isImageLoading ? <Icons.spinner className="w-5 h-5 animate-spin" /> : <Icons.vision className="w-5 h-5"/>}
            </button>
        </div>
      </div>
    </header>
  );
};

export default Header;