import React from 'react';

interface SpherePanelProps {
  title: string;
  icon: React.ReactNode;
  titleColorClass: string;
  children: React.ReactNode;
  className?: string;
}

const SpherePanel: React.FC<SpherePanelProps> = ({ title, icon, titleColorClass, children, className = "" }) => {
  return (
    <div className={`prophet-panel p-6 ${className}`}>
      <h3 className={`text-xl font-semibold mb-4 flex items-center gap-2 ${titleColorClass}`}>
        {icon}
        {title}
      </h3>
      {children}
    </div>
  );
};

export default SpherePanel;
