import React, { useState } from 'react';
import { Transaction, TransactionType } from '../types';

interface FinancialInputFormProps {
  onAddTransaction: (transaction: Omit<Transaction, 'id' | 'date'>) => void;
}

const FinancialInputForm: React.FC<FinancialInputFormProps> = ({ onAddTransaction }) => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<TransactionType>(TransactionType.EXPENSE);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !amount || parseFloat(amount) <= 0) {
      alert('Please fill in all fields with valid values.');
      return;
    }
    onAddTransaction({ description, amount: parseFloat(amount), type });
    setDescription('');
    setAmount('');
  };

  return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-300">Description</label>
          <input
            type="text"
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="mt-1 block w-full bg-gray-900 border border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-purple-500 focus:border-purple-500 sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-gray-300">Amount</label>
          <input
            type="number"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="mt-1 block w-full bg-gray-900 border border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-purple-500 focus:border-purple-500 sm:text-sm"
            min="0.01"
            step="0.01"
          />
        </div>
        <div className="flex items-center space-x-4">
          <label className="text-sm font-medium text-gray-300">Type</label>
          <div className="flex items-center">
            <input
              id="expense"
              name="type"
              type="radio"
              checked={type === TransactionType.EXPENSE}
              onChange={() => setType(TransactionType.EXPENSE)}
              className="h-4 w-4 text-red-500 bg-gray-700 border-gray-600 focus:ring-red-500"
            />
            <label htmlFor="expense" className="ml-2 block text-sm text-red-400">Expense</label>
          </div>
          <div className="flex items-center">
            <input
              id="income"
              name="type"
              type="radio"
              checked={type === TransactionType.INCOME}
              onChange={() => setType(TransactionType.INCOME)}
              className="h-4 w-4 text-green-500 bg-gray-700 border-gray-600 focus:ring-green-500"
            />
            <label htmlFor="income" className="ml-2 block text-sm text-green-400">Income</label>
          </div>
        </div>
        <button
          type="submit"
          className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out transform hover:scale-105 shadow-md"
        >
          Add Transaction
        </button>
      </form>
  );
};

export default FinancialInputForm;
