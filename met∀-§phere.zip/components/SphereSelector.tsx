
import React from 'react';
import { Sphere } from '../types';
import { Icons } from './Icons';

interface SphereSelectorProps {
  activeSphere: Sphere;
  setActiveSphere: (sphere: Sphere) => void;
}

const SphereSelector: React.FC<SphereSelectorProps> = ({ activeSphere, setActiveSphere }) => {
  const spheres = [
    { type: Sphere.ULTRAVIOLET, label: 'FINANCE', icon: Icons.balance, color: 'bg-purple-600', glowColor: '#a855f7' },
    { type: Sphere.INFRARED, label: 'INTERACTIONS', icon: Icons.users, color: 'bg-red-600', glowColor: '#ef4444' },
    { type: Sphere.WHITE, label: 'LEARNING', icon: Icons.brain, color: 'bg-blue-600', glowColor: '#3b82f6' },
    { type: Sphere.BLACK, label: 'THOUGHTS', icon: Icons.messageCircle, color: 'bg-gray-600', glowColor: '#6b7280' },
    { type: Sphere.RED, label: 'LAND', icon: Icons.land, color: 'bg-orange-600', glowColor: '#f97316' },
    { type: Sphere.BLUE, label: 'AIR', icon: Icons.air, color: 'bg-cyan-600', glowColor: '#06b6d4' },
    { type: Sphere.YELLOW, label: 'SEA', icon: Icons.sea, color: 'bg-yellow-600', glowColor: '#eab308' },
  ];

  const radius = 110; // pixels

  return (
    <div className="prophet-panel p-4 flex items-center justify-center">
      <div className="sphere-selector-container">
        <div className="sphere-selector-center">
            <Icons.logo className="w-16 h-16 animate-pulse"/>
        </div>
        {spheres.map((sphere, index) => {
          const angle = (index / spheres.length) * 2 * Math.PI - (Math.PI / 2); // Start from top
          const x = radius * Math.cos(angle);
          const y = radius * Math.sin(angle);
          const isActive = activeSphere === sphere.type;

          return (
            <button
              key={sphere.type}
              onClick={() => setActiveSphere(sphere.type)}
              className={`sphere-selector-button ${
                isActive ? `${sphere.color} text-white shadow-lg scale-110 z-10 glowing` : 'bg-gray-800/80 hover:bg-gray-700 text-gray-300'
              }`}
              style={{
                transform: `translate(${x}px, ${y}px) scale(${isActive ? 1.1 : 1})`,
                '--glow-color': sphere.glowColor
              } as React.CSSProperties}
              aria-label={`Select ${sphere.label} Sphere`}
            >
              <sphere.icon className="w-6 h-6" />
              <span className="text-xs font-bold tracking-wider">{sphere.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default SphereSelector;