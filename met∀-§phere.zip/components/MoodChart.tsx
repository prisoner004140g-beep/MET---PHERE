import React, { useEffect, useRef } from 'react';
import { ThoughtEntry } from '../types';

declare const d3: any;

interface MoodChartProps {
  entries: ThoughtEntry[];
}

const MoodChart: React.FC<MoodChartProps> = ({ entries }) => {
  const ref = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!entries || entries.length === 0) {
      d3.select(ref.current).selectAll("*").remove();
      return;
    }

    const moodCounts = entries.reduce((acc, entry) => {
      acc[entry.mood] = (acc[entry.mood] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const data = Object.entries(moodCounts).map(([mood, count]) => ({ mood, count }));

    const svg = d3.select(ref.current);
    svg.selectAll("*").remove();

    const parent = svg.node().parentElement;
    const parentWidth = parent.clientWidth;
    const height = 200;
    const radius = Math.min(parentWidth, height) / 2 - 10;

    svg.attr("width", parentWidth).attr("height", height);

    const g = svg.append("g").attr("transform", `translate(${parentWidth / 2},${height / 2})`);

    const color = d3.scaleOrdinal()
        .domain(data.map(d => d.mood))
        .range(d3.schemeCategory10.map((c: string) => d3.color(c).brighter(0.2)));

    const pie = d3.pie().value((d: any) => d.count);
    const path = d3.arc().outerRadius(radius).innerRadius(radius - 40);

    const arcs = g.selectAll(".arc")
        .data(pie(data))
        .enter().append("g")
        .attr("class", "arc");

    const tooltip = d3.select("body").append("div")
        .attr("class", "d3-tooltip")
        .style("position", "absolute")
        .style("z-index", "10")
        .style("visibility", "hidden")
        .style("background", "#1f2937")
        .style("border", "1px solid #4b5563")
        .style("border-radius", "8px")
        .style("padding", "8px")
        .style("color", "#d1d5db")
        .style("font-size", "12px");

    arcs.append("path")
        .attr("d", path)
        .attr("fill", (d: any) => color(d.data.mood) as string)
        .attr("stroke", "#0c0a09")
        .style("stroke-width", "2px")
        .on("mouseover", (event: MouseEvent, d: any) => {
            d3.select(event.currentTarget).transition().duration(200).attr('d', d3.arc().outerRadius(radius + 5).innerRadius(radius - 35));
            tooltip.style("visibility", "visible").html(`<strong>${d.data.mood}:</strong> ${d.data.count} (${((d.data.count / entries.length) * 100).toFixed(1)}%)`);
        })
        .on("mousemove", (event: MouseEvent) => tooltip.style("top", (event.pageY-10)+"px").style("left",(event.pageX+10)+"px"))
        .on("mouseout", (event: MouseEvent) => {
            d3.select(event.currentTarget).transition().duration(200).attr('d', path);
            tooltip.style("visibility", "hidden");
        });

    return () => {
        tooltip.remove();
    };

  }, [entries]);

  if (entries.length === 0) {
    return <p className="text-center text-gray-500 py-8">No mood data to display.</p>;
  }

  return (
    <div className="w-full">
      <svg ref={ref}></svg>
    </div>
  );
};

export default MoodChart;
