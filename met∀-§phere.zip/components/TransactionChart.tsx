import React, { useEffect, useRef } from 'react';
import { Transaction, TransactionType } from '../types';

declare const d3: any;

interface TransactionChartProps {
  transactions: Transaction[];
}

type DailyData = { date: Date; income: number; expense: number };

const TransactionChart: React.FC<TransactionChartProps> = ({ transactions }) => {
  const ref = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!transactions || transactions.length === 0) {
      d3.select(ref.current).selectAll("*").remove();
      return;
    }

    // Fix: Explicitly type `dataByDate` to ensure correct type inference for `Object.values`.
    const dataByDate: Record<string, DailyData> = transactions.reduce((acc: Record<string, DailyData>, t) => {
      const date = new Date(t.date).toISOString().split('T')[0];
      if (!acc[date]) {
        acc[date] = { date: new Date(date), income: 0, expense: 0 };
      }
      if (t.type === TransactionType.INCOME) {
        acc[date].income += t.amount;
      } else {
        acc[date].expense += t.amount;
      }
      return acc;
    }, {} as Record<string, DailyData>);
    
    const data: DailyData[] = Object.values(dataByDate).sort((a, b) => a.date.getTime() - b.date.getTime());

    const svg = d3.select(ref.current);
    svg.selectAll("*").remove();

    const parent = svg.node().parentElement;
    const parentWidth = parent.clientWidth;

    const margin = { top: 20, right: 20, bottom: 40, left: 60 };
    const width = parentWidth - margin.left - margin.right;
    const height = 300 - margin.top - margin.bottom;

    svg.attr("width", parentWidth).attr("height", 300);

    const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);
    
    const x = d3.scaleBand()
        .rangeRound([0, width])
        .padding(0.2)
        .domain(data.map((d: DailyData) => d.date));

    const y = d3.scaleLinear()
        .rangeRound([height, 0])
        .domain([0, d3.max(data, (d: DailyData) => Math.max(d.income, d.expense)) * 1.1 || 10]);

    g.append("g")
        .attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(x).tickFormat(d3.timeFormat("%b %d")))
        .selectAll("text")
        .style("fill", "#9ca3af")
        .attr("transform", "translate(-10,0)rotate(-45)")
        .style("text-anchor", "end");

    g.append("g")
        .call(d3.axisLeft(y).ticks(5).tickFormat((d: any) => `$${d3.format(",.0f")(d)}`))
        .selectAll("text")
        .style("fill", "#9ca3af");

    // Tooltip
    const tooltip = d3.select("body").append("div")
        .attr("class", "d3-tooltip")
        .style("position", "absolute")
        .style("z-index", "10")
        .style("visibility", "hidden")
        .style("background", "#1f2937")
        .style("border", "1px solid #4b5563")
        .style("border-radius", "8px")
        .style("padding", "8px")
        .style("color", "#d1d5db")
        .style("font-size", "12px");

    const formatCurrency = (d: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(d);

    g.selectAll(".bar-income")
      .data(data)
      .enter().append("rect")
        .attr("class", "bar-income")
        .attr("x", (d: DailyData) => x(d.date)!)
        .attr("y", (d: DailyData) => y(d.income)!)
        .attr("width", x.bandwidth() / 2)
        .attr("height", (d: DailyData) => height - y(d.income)!)
        .attr("fill", "#4ade80")
        .on("mouseover", (event: MouseEvent, d: DailyData) => {
            tooltip.style("visibility", "visible").html(`<strong>Income:</strong> ${formatCurrency(d.income)}`);
        })
        .on("mousemove", (event: MouseEvent) => tooltip.style("top", (event.pageY-10)+"px").style("left",(event.pageX+10)+"px"))
        .on("mouseout", () => tooltip.style("visibility", "hidden"));

    g.selectAll(".bar-expense")
      .data(data)
      .enter().append("rect")
        .attr("class", "bar-expense")
        .attr("x", (d: DailyData) => x(d.date)! + x.bandwidth() / 2)
        .attr("y", (d: DailyData) => y(d.expense)!)
        .attr("width", x.bandwidth() / 2)
        .attr("height", (d: DailyData) => height - y(d.expense)!)
        .attr("fill", "#f87171")
        .on("mouseover", (event: MouseEvent, d: DailyData) => {
            tooltip.style("visibility", "visible").html(`<strong>Expense:</strong> ${formatCurrency(d.expense)}`);
        })
        .on("mousemove", (event: MouseEvent) => tooltip.style("top", (event.pageY-10)+"px").style("left",(event.pageX+10)+"px"))
        .on("mouseout", () => tooltip.style("visibility", "hidden"));

    return () => {
        tooltip.remove();
    };

  }, [transactions]);
  
  if (transactions.length === 0) {
      return <p className="text-center text-gray-500 py-8">No transaction data to display.</p>;
  }

  return (
    <>
      <div className="w-full overflow-x-auto">
        <svg ref={ref}></svg>
      </div>
      <div className="flex justify-center gap-4 text-xs mt-2">
        <div className="flex items-center gap-1"><div className="w-3 h-3 bg-green-400 rounded-sm"></div><span>Income</span></div>
        <div className="flex items-center gap-1"><div className="w-3 h-3 bg-red-400 rounded-sm"></div><span>Expense</span></div>
      </div>
    </>
  );
};

export default TransactionChart;
