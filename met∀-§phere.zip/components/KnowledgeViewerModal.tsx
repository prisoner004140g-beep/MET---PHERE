

import React, { useState, useRef, useEffect } from 'react';
import { KnowledgeEntry, KnowledgeEntryType } from '../types';
import { Icons } from './Icons';
import { generateSpeech } from '../services/geminiService';

interface KnowledgeViewerModalProps {
  entry: KnowledgeEntry;
  allEntries: KnowledgeEntry[];
  onViewNewEntry: (entry: KnowledgeEntry) => void;
  onClose: () => void;
}

const KnowledgeViewerModal: React.FC<KnowledgeViewerModalProps> = ({ entry, allEntries, onViewNewEntry, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  const stopAudio = () => {
    if (audioSourceRef.current) {
        audioSourceRef.current.stop();
        audioSourceRef.current.disconnect();
        audioSourceRef.current = null;
    }
    if (audioContextRef.current) {
        audioContextRef.current.close().then(() => {
            audioContextRef.current = null;
        });
    }
    setIsPlaying(false);
    setIsLoadingAudio(false);
  };

  useEffect(() => {
    // Cleanup function to stop audio when the modal is closed or the entry changes
    return () => {
        stopAudio();
    };
  }, [entry.id]);

  const handlePlayNarration = async () => {
    if (isPlaying || isLoadingAudio) {
        stopAudio();
        return;
    }

    setIsLoadingAudio(true);
    try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioContextRef.current = audioContext;

        const audioData = await generateSpeech(entry.content);
        
        const decodedData = atob(audioData);
        const buffer = new Uint8Array(decodedData.length);
        for(let i = 0; i < decodedData.length; ++i) {
            buffer[i] = decodedData.charCodeAt(i);
        }

        const dataInt16 = new Int16Array(buffer.buffer);
        const frameCount = dataInt16.length;
        const audioBuffer = audioContext.createBuffer(1, frameCount, 24000);
        const channelData = audioBuffer.getChannelData(0);
        for (let i = 0; i < frameCount; i++) {
            channelData[i] = dataInt16[i] / 32768.0;
        }

        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        source.onended = () => {
            setIsPlaying(false);
            if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
                audioContextRef.current.close();
            }
            audioContextRef.current = null;
            audioSourceRef.current = null;
        };
        source.start();
        audioSourceRef.current = source;
        setIsPlaying(true);

    } catch (error) {
        console.error('TTS error:', error);
        alert('Failed to generate narration.');
    } finally {
        setIsLoadingAudio(false);
    }
  };


  const relatedEntries = allEntries.filter(e => {
      if (e.id === entry.id) return false;
      const entryTags = new Set(entry.tags.split(',').map(t => t.trim()).filter(Boolean));
      if (entryTags.size === 0) return false;
      const otherTags = e.tags.split(',').map(t => t.trim()).filter(Boolean);
      return otherTags.some(tag => entryTags.has(tag));
  }).slice(0, 5); // Limit to 5 related entries

  const isTutorial = entry.entryType === KnowledgeEntryType.TUTORIAL;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-gray-800 rounded-lg shadow-2xl w-11/12 max-w-2xl max-h-[80vh] p-6 flex flex-col border border-blue-500/30 modal-content" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-start mb-4 border-b border-gray-700 pb-4">
          <div className="flex-grow">
            <h2 className="text-2xl font-bold text-blue-300 flex items-center gap-3">
              {isTutorial ? <Icons.bookOpen className="w-7 h-7" /> : <Icons.manifesto className="w-7 h-7" />}
              {entry.title}
            </h2>
            {isTutorial && (
              <button 
                onClick={handlePlayNarration}
                disabled={isLoadingAudio}
                className="mt-2 flex items-center gap-2 text-sm text-purple-300 hover:text-white disabled:opacity-50 disabled:cursor-wait"
              >
                {isLoadingAudio ? (
                  <>
                    <Icons.spinner className="w-4 h-4 animate-spin" />
                    Loading...
                  </>
                ) : isPlaying ? (
                  <>
                    <Icons.stopCircle className="w-5 h-5" />
                    Stop Narration
                  </>
                ) : (
                  <>
                    <Icons.play className="w-5 h-5" />
                    Play Narration
                  </>
                )}
              </button>
            )}
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors ml-4 flex-shrink-0">
            <Icons.close className="w-6 h-6" />
          </button>
        </div>
        <div className="flex-grow overflow-y-auto pr-4">
            <p className="text-gray-200 whitespace-pre-wrap leading-relaxed">{entry.content}</p>
        </div>
        <div className="mt-4 border-t border-gray-700 pt-4 flex flex-wrap gap-2">
            {entry.tags.split(',').map(tag => tag.trim()).filter(Boolean).map((tag, index) => (
                <span key={index} className="text-xs bg-blue-900/50 text-blue-300 px-2 py-1 rounded-full">{tag}</span>
            ))}
        </div>
        {relatedEntries.length > 0 && (
            <div className="mt-6 border-t border-gray-700 pt-4">
                <h4 className="text-lg font-semibold text-blue-200 mb-2">Related Entries</h4>
                <div className="space-y-2">
                    {relatedEntries.map(related => (
                        <button 
                            key={related.id} 
                            onClick={() => onViewNewEntry(related)} 
                            className="text-left w-full p-2 bg-gray-900/50 rounded-md hover:bg-gray-700 transition-colors"
                        >
                            <p className="font-semibold text-blue-300">{related.title}</p>
                            <p className="text-xs text-gray-400">{related.content.substring(0, 80)}...</p>
                        </button>
                    ))}
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default KnowledgeViewerModal;