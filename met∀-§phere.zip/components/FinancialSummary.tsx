import React from 'react';
import { Icons } from './Icons';

interface FinancialSummaryProps {
  totalIncome: number;
  totalExpenses: number;
  balance: number;
}

const FinancialSummary: React.FC<FinancialSummaryProps> = ({ totalIncome, totalExpenses, balance }) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center p-3 bg-green-900/30 rounded-md">
        <div className="flex items-center gap-3">
          <Icons.income className="w-6 h-6 text-green-400" />
          <span className="font-medium text-green-300">Total Income</span>
        </div>
        <span className="font-semibold text-lg text-green-400">{formatCurrency(totalIncome)}</span>
      </div>
      <div className="flex justify-between items-center p-3 bg-red-900/30 rounded-md">
        <div className="flex items-center gap-3">
          <Icons.expense className="w-6 h-6 text-red-400" />
          <span className="font-medium text-red-300">Total Expenses</span>
        </div>
        <span className="font-semibold text-lg text-red-400">{formatCurrency(totalExpenses)}</span>
      </div>
      <div className="flex justify-between items-center p-4 bg-blue-900/30 rounded-md border-t-2 border-blue-400">
        <div className="flex items-center gap-3">
          <Icons.balance className="w-6 h-6 text-blue-300" />
          <span className="font-medium text-blue-200">Current Balance</span>
        </div>
        <span className={`font-bold text-2xl ${balance >= 0 ? 'text-blue-300' : 'text-red-400'}`}>
          {formatCurrency(balance)}
        </span>
      </div>
    </div>
  );
};

export default FinancialSummary;
