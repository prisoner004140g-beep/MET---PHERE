import React, { useMemo } from 'react';
import { ChatMessage, Transaction, Contact, Relationship, KnowledgeEntry, ThoughtEntry, ChatRole, KnowledgeEntryType, TransactionType, AiRole, Sphere } from '../types';
import { Icons } from './Icons';

interface VisionPaneVisualizationProps {
    appContext: {
        transactions: Transaction[];
        contacts: Contact[];
        relationships: Relationship[];
        knowledgeEntries: KnowledgeEntry[];
        thoughtEntries: ThoughtEntry[];
    };
    chatHistory: ChatMessage[];
    aiRole: AiRole;
    activeSphere: Sphere;
    onSphereSelect: (sphere: Sphere) => void;
}

const Sparkline: React.FC<{ data: number[], color: string }> = ({ data, color }) => {
    if (data.length < 2) return null;
    const width = 80;
    const height = 20;
    const maxVal = Math.max(...data);
    const minVal = Math.min(...data);
    const range = maxVal - minVal === 0 ? 1 : maxVal - minVal;

    const points = data.map((d, i) => {
        const x = (i / (data.length - 1)) * width;
        const y = height - ((d - minVal) / range) * (height - 2) + 1; // -2/+1 for padding
        return `${x},${y}`;
    }).join(' ');

    return (
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-5 mt-1">
            <polyline
                points={points}
                className="sparkline-path"
                stroke={color}
            />
        </svg>
    );
};

const VisionPaneVisualization: React.FC<VisionPaneVisualizationProps> = ({ appContext, chatHistory, aiRole, activeSphere, onSphereSelect }) => {
    const { transactions, contacts, relationships, knowledgeEntries, thoughtEntries } = appContext;

    // --- ANALYTICAL METRICS ---
    const financialSummary = useMemo(() => {
        const balance = transactions.reduce((acc, t) => acc + (t.type === TransactionType.INCOME ? t.amount : -t.amount), 0);
        
        // Data for last 7 days sparkline
        const dailyNet: { [key: string]: number } = {};
        const today = new Date();
        for (let i = 6; i >= 0; i--) {
            const d = new Date(today);
            d.setDate(today.getDate() - i);
            const key = d.toISOString().split('T')[0];
            dailyNet[key] = 0;
        }
        transactions.forEach(t => {
            const key = new Date(t.date).toISOString().split('T')[0];
            if (key in dailyNet) {
                dailyNet[key] += (t.type === TransactionType.INCOME ? t.amount : -t.amount);
            }
        });

        return {
            balance: new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(balance),
            sparklineData: Object.values(dailyNet)
        };
    }, [transactions]);
    
    const infraredSummary = useMemo(() => {
        const density = contacts.length > 1 ? (relationships.length / (contacts.length * (contacts.length - 1))) : 0;
        return {
            contacts: contacts.length,
            relationships: relationships.length,
            density: `${(density * 100).toFixed(2)}%`
        };
    }, [contacts, relationships]);

    const whiteSummary = useMemo(() => {
        const userEntries = knowledgeEntries.filter(e => e.entryType !== KnowledgeEntryType.MANIFESTO);
        const allTags = userEntries.flatMap(e => e.tags.split(',').map(t => t.trim()).filter(Boolean));
        const tagCounts = allTags.reduce((acc, tag) => {
            acc[tag] = (acc[tag] || 0) + 1;
            return acc;
        }, {} as Record<string, number>);
        // FIX: Sort by count (the second element in each [key, value] pair) in descending order to find the most frequent tag.
        // The previous implementation used parameter destructuring in a way that confused TypeScript's type inference. Switched to safer array indexing.
        const topTag = Object.entries(tagCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';
        return { count: userEntries.length, topTag };
    }, [knowledgeEntries]);
    
    const blackSummary = useMemo(() => {
        // Data for last 7 days sparkline
        const dailyEntries: { [key: string]: number } = {};
        const today = new Date();
        for (let i = 6; i >= 0; i--) {
            const d = new Date(today);
            d.setDate(today.getDate() - i);
            const key = d.toISOString().split('T')[0];
            dailyEntries[key] = 0;
        }
        thoughtEntries.forEach(t => {
            const key = new Date(t.timestamp).toISOString().split('T')[0];
            if (key in dailyEntries) {
                dailyEntries[key]++;
            }
        });

        return {
            count: thoughtEntries.length,
            sparklineData: Object.values(dailyEntries)
        };
    }, [thoughtEntries]);

    // --- LIVE FEEDS ---
    const recentChat = chatHistory.slice(-3);
    const recentThoughts = thoughtEntries.slice(-3).reverse();

    return (
        <div className="w-full h-full p-3 z-10 flex gap-4 text-white">
            {/* Left Column: Context Matrix */}
            <div className="w-5/12 flex flex-col gap-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400">Context Matrix</h4>
                <div className="flex-grow grid grid-cols-2 grid-rows-2 gap-3">
                    <button onClick={() => onSphereSelect(Sphere.ULTRAVIOLET)} className="bg-gray-900/60 rounded-lg p-3 flex flex-col justify-between border-l-4 border-purple-500 w-full text-left hover:bg-gray-800/80 transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500">
                        <div>
                            <p className="text-purple-300 font-bold flex items-center gap-2"><Icons.balance className="w-4 h-4" />Ultraviolet</p>
                            <p className="text-xs text-gray-400">Financial Flow</p>
                        </div>
                        <div>
                            <p className="text-2xl font-bold">{financialSummary.balance}</p>
                            <Sparkline data={financialSummary.sparklineData} color="#a855f7" />
                        </div>
                    </button>
                     <button onClick={() => onSphereSelect(Sphere.INFRARED)} className="bg-gray-900/60 rounded-lg p-3 flex flex-col justify-between border-l-4 border-red-500 w-full text-left hover:bg-gray-800/80 transition-colors focus:outline-none focus:ring-2 focus:ring-red-500">
                        <div>
                            <p className="text-red-300 font-bold flex items-center gap-2"><Icons.users className="w-4 h-4" />Infrared</p>
                            <p className="text-xs text-gray-400">Interaction Network</p>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-center">
                           <div><p className="text-xl font-bold">{infraredSummary.contacts}</p><p className="text-xs text-gray-400">Contacts</p></div>
                           <div><p className="text-xl font-bold">{infraredSummary.relationships}</p><p className="text-xs text-gray-400">Links</p></div>
                        </div>
                    </button>
                     <button onClick={() => onSphereSelect(Sphere.WHITE)} className="bg-gray-900/60 rounded-lg p-3 flex flex-col justify-between border-l-4 border-blue-500 w-full text-left hover:bg-gray-800/80 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <div>
                            <p className="text-blue-300 font-bold flex items-center gap-2"><Icons.brain className="w-4 h-4" />White</p>
                            <p className="text-xs text-gray-400">Metaversity</p>
                        </div>
                        <div>
                           <p className="text-xl font-bold">{whiteSummary.count}</p><p className="text-xs text-gray-400">Entries</p>
                           <p className="text-xs text-gray-400 mt-1">Top Tag: <span className="font-semibold text-blue-200">{whiteSummary.topTag}</span></p>
                        </div>
                    </button>
                     <button onClick={() => onSphereSelect(Sphere.BLACK)} className="bg-gray-900/60 rounded-lg p-3 flex flex-col justify-between border-l-4 border-gray-500 w-full text-left hover:bg-gray-800/80 transition-colors focus:outline-none focus:ring-2 focus:ring-gray-500">
                        <div>
                           <p className="text-gray-300 font-bold flex items-center gap-2"><Icons.messageCircle className="w-4 h-4" />Black</p>
                           <p className="text-xs text-gray-400">Thought Stream</p>
                        </div>
                         <div>
                            <p className="text-2xl font-bold">{blackSummary.count}</p>
                            <Sparkline data={blackSummary.sparklineData} color="#9ca3af" />
                        </div>
                    </button>
                </div>
            </div>

            {/* Center Column: AI Core */}
            <div className="w-2/12 flex flex-col items-center justify-center gap-2 relative">
                <svg viewBox="0 0 100 100" className="w-full h-auto max-w-[120px]">
                    <defs>
                        <filter id="glow">
                            <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
                            <feMerge>
                                <feMergeNode in="coloredBlur"/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                    <circle cx="50" cy="50" r="48" fill="none" stroke="rgba(168, 85, 247, 0.1)" strokeWidth="2"/>
                    <circle cx="50" cy="50" r="40" fill="none" stroke="#a855f7" strokeWidth="1" className="ai-core-pulse-1" />
                    <circle cx="50" cy="50" r="30" fill="none" stroke="#a855f7" strokeWidth="1" className="ai-core-pulse-2" />
                    <circle cx="50" cy="50" r="20" fill="none" stroke="#a855f7" strokeWidth="1" className="ai-core-pulse-3" />
                    <path d="M50,10 L50,35 M50,65 L50,90 M10,50 L35,50 M65,50 L90,50" stroke="#a855f7" strokeWidth="1" strokeLinecap="round" opacity="0.5"/>
                </svg>
                 <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <p className="text-xs font-bold uppercase tracking-wider text-gray-400">AI CORE</p>
                    <p className="text-lg font-bold text-purple-300">{aiRole.toUpperCase()}</p>
                    <p className="text-xs text-gray-400 mt-2">FOCUS:</p>
                    <p className="text-sm font-semibold text-white">{activeSphere.split(' ')[0]}</p>
                </div>
            </div>

            {/* Right Column: Live Feeds */}
            <div className="w-5/12 flex flex-col gap-4">
                <div className="flex-1 flex flex-col">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">Recent Dialogue</h4>
                     <div className="flex-grow space-y-2 text-xs">
                        {recentChat.map((msg, index) => (
                             <p key={index} className="truncate fade-in-item" style={{animationDelay: `${index * 100}ms`}}>
                                <span className={msg.role === ChatRole.USER ? 'text-blue-400 font-semibold' : 'text-purple-300 font-semibold'}>
                                    {msg.role === ChatRole.USER ? 'Prophet: ' : 'AI: '}
                                </span>
                                <span className="text-gray-300">{msg.parts[0].text}</span>
                            </p>
                        ))}
                     </div>
                </div>
                <div className="flex-1 flex flex-col">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">Recent Thoughts</h4>
                    <div className="flex-grow space-y-2 text-xs">
                         {recentThoughts.map((thought, index) => (
                             <div key={thought.id} className="bg-gray-900/50 p-2 rounded fade-in-item" style={{animationDelay: `${index * 100}ms`}}>
                                <p className="font-semibold text-gray-300 truncate">{thought.content}</p>
                                <p className="text-gray-400">{thought.mood}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default VisionPaneVisualization;