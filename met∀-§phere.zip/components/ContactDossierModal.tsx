

import React from 'react';
import { Contact, Transaction, Relationship, KnowledgeEntry, ThoughtEntry, RelationshipType, TransactionType, KnowledgeEntryType } from '../types';
import { Icons } from './Icons';

interface ContactDossierModalProps {
  contact: Contact;
  appContext: {
    transactions: Transaction[];
    relationships: Relationship[];
    knowledgeEntries: KnowledgeEntry[];
    thoughtEntries: ThoughtEntry[];
    contacts: Contact[];
  };
  onClose: () => void;
}

const Section: React.FC<{ title: string; icon: React.FC<any>; color: string; children: React.ReactNode; count: number }> = ({ title, icon: Icon, color, children, count }) => (
    <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-700">
        <h3 className={`text-lg font-semibold mb-3 flex items-center gap-2 ${color}`}>
            <Icon className="w-5 h-5" />
            {title} ({count})
        </h3>
        {count > 0 ? <div className="space-y-3 pl-2">{children}</div> : <p className="text-sm text-gray-500 pl-2">No related entries found in this sphere.</p>}
    </div>
);

const ContactDossierModal: React.FC<ContactDossierModalProps> = ({ contact, appContext, onClose }) => {
    const { transactions, relationships, knowledgeEntries, thoughtEntries, contacts } = appContext;

    const contactNameLower = contact.name.toLowerCase();

    // Filter data from each sphere related to the contact
    const relatedTransactions = transactions.filter(t => 
        t.description.toLowerCase().includes(contactNameLower)
    );

    const relatedRelationships = relationships.filter(r => 
        r.sourceId === contact.id || r.targetId === contact.id
    );

    const relatedKnowledge = knowledgeEntries.filter(k => 
        k.entryType !== KnowledgeEntryType.LINGUISTICS &&
        (k.tags.toLowerCase().includes(contactNameLower) || 
        k.title.toLowerCase().includes(contactNameLower) ||
        k.content.toLowerCase().includes(contactNameLower))
    );

    const relatedThoughts = thoughtEntries.filter(t => 
        t.tags?.toLowerCase().includes(contactNameLower) ||
        t.content.toLowerCase().includes(contactNameLower)
    );
    
    const relatedLinguisticKnowledge = knowledgeEntries.filter(k => 
        k.entryType === KnowledgeEntryType.LINGUISTICS && 
        contact.language?.toLowerCase().split(',').some(lang => k.tags.includes(lang.trim()))
    );

    const getContactName = (id: number) => contacts.find(c => c.id === id)?.name || 'Unknown Contact';
    const relationshipTypeStyles: Record<RelationshipType, { icon: React.FC<any>, color: string }> = {
      [RelationshipType.FRIENDSHIP]: { icon: Icons.heart, color: 'text-pink-400' },
      [RelationshipType.CONFLICT]: { icon: Icons.zap, color: 'text-red-400' },
      [RelationshipType.NETWORKING]: { icon: Icons.share, color: 'text-green-400' },
      [RelationshipType.ASSOCIATE]: { icon: Icons.fileText, color: 'text-gray-400' },
    };


    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" onClick={onClose}>
            <div className="bg-gray-800 rounded-lg shadow-2xl w-11/12 max-w-4xl h-5/6 p-6 flex flex-col border border-red-500/30 modal-content" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4 border-b border-gray-700 pb-4 flex-shrink-0">
                    <div>
                        <h2 className="text-2xl font-bold text-red-300 flex items-center gap-3">
                            <Icons.user className="w-7 h-7" />
                            Dossier: {contact.name}
                        </h2>
                        {contact.notes && <p className="text-sm text-gray-400 ml-10 mt-1">{contact.notes}</p>}
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <Icons.close className="w-6 h-6" />
                    </button>
                </div>
                
                <div className="flex-grow overflow-y-auto pr-4 grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Column 1 */}
                    <div className="flex flex-col gap-6">
                        <Section title="Ultraviolet" icon={Icons.balance} color="text-purple-300" count={relatedTransactions.length}>
                           {relatedTransactions.map(t => (
                               <div key={t.id} className={`text-sm text-gray-300 flex justify-between items-center p-2 rounded-md ${t.type === TransactionType.INCOME ? 'bg-green-900/20' : 'bg-red-900/20'}`}>
                                   <p>{t.description}</p>
                                   <span className={`font-semibold ${t.type === TransactionType.INCOME ? 'text-green-400' : 'text-red-400'}`}>{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(t.amount)}</span>
                               </div>
                           ))}
                        </Section>
                        
                        <Section title="White" icon={Icons.brain} color="text-blue-300" count={relatedKnowledge.length}>
                            {relatedKnowledge.map(k => (
                                <div key={k.id} className="text-sm text-gray-300 border-l-2 border-gray-600 pl-3">
                                    <p className="font-semibold">{k.title}</p>
                                    <p className="text-xs text-gray-400">{k.content.substring(0, 100)}...</p>
                                </div>
                            ))}
                        </Section>

                        {contact.language && (
                            <Section title="Linguistics" icon={Icons.messageCircle} color="text-cyan-300" count={relatedLinguisticKnowledge.length}>
                                <p className="text-sm text-gray-300 mb-3 border-b border-gray-700 pb-2">
                                    <strong>Language(s):</strong> {contact.language}
                                </p>
                                {relatedLinguisticKnowledge.map(k => (
                                    <div key={k.id} className="text-sm text-gray-300 border-l-2 border-gray-600 pl-3">
                                        <p className="font-semibold">{k.title}</p>
                                        <p className="text-xs text-gray-400">{k.content.substring(0, 100)}...</p>
                                    </div>
                                ))}
                            </Section>
                        )}
                    </div>
                    
                    {/* Column 2 */}
                    <div className="flex flex-col gap-6">
                         <Section title="Infrared" icon={Icons.users} color="text-red-300" count={relatedRelationships.length}>
                             {relatedRelationships.map(r => {
                                 const otherContactId = r.sourceId === contact.id ? r.targetId : r.sourceId;
                                 const otherContactName = getContactName(otherContactId);
                                 const typeInfo = relationshipTypeStyles[r.relationshipType];
                                 const Icon = typeInfo.icon;
                                 return (
                                     <div key={r.id} className="text-sm text-gray-300">
                                        <div className="flex justify-between items-center">
                                            <p><span className="font-bold text-red-200">{contact.name}</span> → <span className="font-bold text-red-200">{otherContactName}</span></p>
                                            <div className={`flex items-center gap-1.5 text-xs font-medium ${typeInfo.color}`}><Icon className="w-3.5 h-3.5" /><span>{r.relationshipType}</span></div>
                                        </div>
                                         <p className="text-xs text-gray-400 border-l-2 border-gray-600 pl-2 mt-1">{r.description}</p>
                                     </div>
                                 );
                             })}
                        </Section>

                        <Section title="Black" icon={Icons.messageCircle} color="text-gray-300" count={relatedThoughts.length}>
                            {relatedThoughts.map(t => (
                                <div key={t.id} className="text-sm text-gray-300 border-l-2 border-gray-600 pl-3">
                                    <div className="flex justify-between items-center text-xs text-gray-400 mb-1">
                                        <span className="font-semibold bg-gray-700 px-2 py-0.5 rounded-full">{t.mood}</span>
                                        <span>{new Date(t.timestamp).toLocaleDateString()}</span>
                                    </div>
                                    <p className="text-gray-300">{t.content.substring(0, 100)}...</p>
                                </div>
                            ))}
                        </Section>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ContactDossierModal;