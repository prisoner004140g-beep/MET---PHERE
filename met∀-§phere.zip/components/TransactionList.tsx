import React from 'react';
import { Transaction, TransactionType } from '../types';
import { Icons } from './Icons';

interface TransactionListProps {
  transactions: Transaction[];
}

const TransactionList: React.FC<TransactionListProps> = ({ transactions }) => {
  const sortedTransactions = [...transactions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  return (
    <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
      {sortedTransactions.length === 0 ? (
        <p className="text-gray-400 text-center py-4">No transactions yet.</p>
      ) : (
        sortedTransactions.map(transaction => (
          <div key={transaction.id} className="flex justify-between items-center bg-gray-900/70 p-3 rounded-md">
            <div className="flex items-center gap-3">
              {transaction.type === TransactionType.INCOME ? 
                <Icons.arrowUp className="w-5 h-5 text-green-500" /> : 
                <Icons.arrowDown className="w-5 h-5 text-red-500" />
              }
              <span className="text-gray-200">{transaction.description}</span>
            </div>
            <span className={`font-semibold ${transaction.type === TransactionType.INCOME ? 'text-green-400' : 'text-red-400'}`}>
              {transaction.type === TransactionType.INCOME ? '+' : '-'}
              {formatCurrency(transaction.amount)}
            </span>
          </div>
        ))
      )}
    </div>
  );
};

export default TransactionList;
