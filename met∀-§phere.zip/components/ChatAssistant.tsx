import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { ChatMessage, ChatRole, AiModel, GroundingChunk, Transaction, Contact, Relationship, KnowledgeEntry, ThoughtEntry, Coordinates, AiRole, Sphere } from '../types';
import { generateResponse, generateSpeech } from '../services/geminiService';
import { useGeolocation } from '../hooks/useGeolocation';
import { Icons } from './Icons';

interface ChatAssistantProps {
  chatHistory: ChatMessage[];
  setChatHistory: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  appContext: { 
    transactions: Transaction[];
    contacts: Contact[];
    relationships: Relationship[];
    knowledgeEntries: KnowledgeEntry[];
    thoughtEntries: ThoughtEntry[];
  };
  aiRole: AiRole;
  activeSphere: Sphere;
}

const modelDescriptions: Record<AiModel, string> = {
    [AiModel.STANDARD]: "Balanced model for general queries and conversation.",
    [AiModel.FAST]: "Quicker responses, suitable for simple tasks.",
    [AiModel.THINKING]: "Most powerful model for complex reasoning and analysis.",
    [AiModel.LOCATION]: "Uses your location for geographically-aware answers.",
};

const ContextSummary: React.FC<{ appContext: ChatAssistantProps['appContext'] }> = ({ appContext }) => {
    const summary = useMemo(() => {
        const { transactions, contacts, thoughtEntries } = appContext;
        const balance = transactions.reduce((acc, t) => acc + (t.type === 'income' ? t.amount : -t.amount), 0);
        const lastThought = thoughtEntries.length > 0 ? thoughtEntries.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0] : null;

        const totalTransactionAmount = transactions.reduce((sum, t) => sum + t.amount, 0);
        const avgTransactionAmount = transactions.length > 0 ? totalTransactionAmount / transactions.length : 0;
        const taggedContactsCount = contacts.filter(c => c.tags && c.tags.trim() !== '').length;

        return {
            balance: new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(balance),
            contactsCount: contacts.length,
            taggedContactsCount,
            avgTransaction: new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(avgTransactionAmount),
            lastThought: lastThought ? `${lastThought.mood}: ${lastThought.content.substring(0, 30)}...` : 'None'
        };
    }, [appContext]);

    return (
        <details className="group text-xs text-gray-400">
            <summary className="cursor-pointer list-none flex items-center gap-1 font-medium group-hover:text-white">
                <span className="transition-transform duration-200 group-open:rotate-90"><Icons.arrowRight className="w-3 h-3"/></span>
                AI Context Summary
            </summary>
            <div className="mt-2 ml-4 pl-2 border-l border-gray-600 grid grid-cols-2 gap-x-4 gap-y-1">
                <p><strong className="text-gray-300">Balance:</strong> {summary.balance}</p>
                <p><strong className="text-gray-300">Contacts:</strong> {summary.contactsCount} ({summary.taggedContactsCount} tagged)</p>
                <p><strong className="text-gray-300">Avg. Transaction:</strong> {summary.avgTransaction}</p>
                <p className="col-span-2"><strong className="text-gray-300">Last Thought:</strong> {summary.lastThought}</p>
            </div>
        </details>
    );
};


const ChatAssistant: React.FC<ChatAssistantProps> = ({ chatHistory, setChatHistory, appContext, aiRole, activeSphere }) => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState<AiModel>(AiModel.STANDARD);
  const [speakingMessageIndex, setSpeakingMessageIndex] = useState<number | null>(null);
  
  const { location, error: geoError, refreshLocation } = useGeolocation();
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = { role: ChatRole.USER, parts: [{ text: input }] };
    const newHistory = [...chatHistory, userMessage];
    setChatHistory(newHistory);
    setInput('');
    setIsLoading(true);

    try {
      let currentLocation = location;
      if (selectedModel === AiModel.LOCATION && !currentLocation) {
          if(geoError) {
             console.warn(`Geolocation error but using fallback: ${geoError}`);
          }
          currentLocation = await refreshLocation();
          if(!currentLocation) {
             throw new Error("Could not retrieve location. Please grant permission and try again.");
          }
      }

      const response = await generateResponse(newHistory, selectedModel, appContext, currentLocation, aiRole, activeSphere);
      const aiMessage: ChatMessage = {
        role: ChatRole.AI,
        parts: [{ text: response.text, grounding: response.groundingChunks }],
      };
      setChatHistory(prev => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
      const aiError: ChatMessage = {
        role: ChatRole.AI,
        parts: [{ text: `Error: ${errorMessage}` }],
      };
      setChatHistory(prev => [...prev, aiError]);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlayAudio = useCallback(async (text: string, index: number) => {
    if (speakingMessageIndex === index) {
        if(audioContextRef.current) {
            audioContextRef.current.close();
            audioContextRef.current = null;
        }
        setSpeakingMessageIndex(null);
        return;
    }
    
    setSpeakingMessageIndex(index);
    try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioContextRef.current = audioContext;
        const audioData = await generateSpeech(text);
        
        const decodedData = atob(audioData);
        const buffer = new Uint8Array(decodedData.length);
        for(let i = 0; i < decodedData.length; ++i) {
            buffer[i] = decodedData.charCodeAt(i);
        }

        const dataInt16 = new Int16Array(buffer.buffer);
        const frameCount = dataInt16.length;
        const audioBuffer = audioContext.createBuffer(1, frameCount, 24000);
        const channelData = audioBuffer.getChannelData(0);
        for (let i = 0; i < frameCount; i++) {
            channelData[i] = dataInt16[i] / 32768.0;
        }

        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        source.onended = () => {
            setSpeakingMessageIndex(null);
            if (audioContextRef.current) {
                audioContextRef.current.close();
                audioContextRef.current = null;
            }
        };
        source.start();

    } catch (error) {
        console.error('TTS error:', error);
        setSpeakingMessageIndex(null);
    }
  }, [speakingMessageIndex]);

  return (
    <div className="prophet-panel flex flex-col h-full max-h-[85vh]">
      <div className="p-4 border-b border-gray-700/50 space-y-3 flex-shrink-0">
        <h2 className="text-xl font-semibold text-purple-300">AI Assistant</h2>
        <div className="flex flex-wrap gap-2">
          {(Object.values(AiModel)).map(model => (
            <button
              key={model}
              onClick={() => setSelectedModel(model)}
              title={modelDescriptions[model]}
              className={`px-3 py-1 text-sm font-medium rounded-full transition-colors ${selectedModel === model ? 'bg-purple-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}
            >
              {model} Mode
            </button>
          ))}
        </div>
        <ContextSummary appContext={appContext} />
      </div>
      <div ref={chatContainerRef} className="flex-grow p-4 overflow-y-auto space-y-4">
        {chatHistory.map((msg, index) => (
          <div key={index} className={`flex gap-3 ${msg.role === ChatRole.USER ? 'justify-end' : ''}`}>
            {msg.role === ChatRole.AI && <Icons.logo className="w-8 h-8 text-purple-400 flex-shrink-0 mt-1" />}
            <div className={`max-w-md lg:max-w-xl rounded-lg px-4 py-2 ${msg.role === ChatRole.USER ? 'bg-blue-600 text-white rounded-br-none' : 'bg-gray-700 text-gray-200 rounded-bl-none'}`}>
              {msg.parts.map((part, partIndex) => (
                <div key={partIndex}>
                    <p className="whitespace-pre-wrap">{part.text}</p>
                    {part.grounding && part.grounding.length > 0 && (
                        <div className="mt-2 border-t border-gray-600 pt-2">
                            <p className="text-xs font-semibold text-purple-300 mb-1">Sources:</p>
                            <ul className="text-xs space-y-1">
                                {part.grounding.map((chunk, chunkIndex) => {
                                    const source = chunk.maps || chunk.web;
                                    return source ? (
                                        <li key={chunkIndex} className="flex items-center gap-1">
                                            <Icons.link className="w-3 h-3 text-gray-400" />
                                            <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline truncate">
                                                {source.title}
                                            </a>
                                        </li>
                                    ) : null;
                                })}
                            </ul>
                        </div>
                    )}
                </div>
              ))}
              {msg.role === ChatRole.AI && (
                <button 
                  onClick={() => handlePlayAudio(msg.parts.map(p => p.text).join('\n'), index)} 
                  className="mt-2 text-purple-300 hover:text-purple-200 transition-colors"
                  aria-label="Play audio"
                >
                  {speakingMessageIndex === index ? <Icons.stop className="w-5 h-5"/> : <Icons.speaker className="w-5 h-5"/>}
                </button>
              )}
            </div>
            {msg.role === ChatRole.USER && <Icons.user className="w-8 h-8 text-blue-400 flex-shrink-0 mt-1" />}
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-3">
            <Icons.logo className="w-8 h-8 text-purple-400 flex-shrink-0 mt-1" />
            <div className="max-w-md lg:max-w-xl rounded-lg px-4 py-2 bg-gray-700 text-gray-200 rounded-bl-none flex items-center">
              <Icons.spinner className="animate-spin w-5 h-5 mr-2" /> Thinking...
            </div>
          </div>
        )}
      </div>
      <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-700/50 flex items-center gap-3 flex-shrink-0">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={`Ask in ${selectedModel} Mode...`}
          className="flex-grow bg-gray-900 border border-gray-600 rounded-full py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
          disabled={isLoading}
        />
        <button type="submit" className="bg-purple-600 hover:bg-purple-700 rounded-full p-3 text-white disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors" disabled={isLoading || !input.trim()}>
          <Icons.send className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
};

export default ChatAssistant;