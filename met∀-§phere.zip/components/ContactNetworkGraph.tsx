import React, { useEffect, useRef } from 'react';
import { Contact, Relationship, ContactType } from '../types';

// D3 is loaded from a script tag in index.html
declare const d3: any;

interface ContactNetworkGraphProps {
  contacts: Contact[];
  relationships: Relationship[];
}

const ContactNetworkGraph: React.FC<ContactNetworkGraphProps> = ({ contacts, relationships }) => {
  const ref = useRef<SVGSVGElement>(null);

  useEffect(() => {
    const svgElement = ref.current;
    if (!contacts || !relationships || !svgElement) {
      return;
    }
    
    d3.select(svgElement).selectAll("*").remove();

    const parent = svgElement.parentElement;
    if (!parent || contacts.length === 0) return;

    const width = parent.clientWidth;
    const height = 400; // Fixed height for the graph area

    const svg = d3.select(svgElement)
      .attr("width", width)
      .attr("height", height)
      .attr("viewBox", [-width / 2, -height / 2, width, height])
      .style("max-width", "100%")
      .style("height", "auto");

    // Process data
    const nodes = contacts.map(c => ({ ...c }));
    const links = relationships.map(r => ({
      source: r.sourceId,
      target: r.targetId,
      type: r.relationshipType
    }));

    const simulation = d3.forceSimulation(nodes)
      .force("link", d3.forceLink(links).id((d: any) => d.id).distance(100))
      .force("charge", d3.forceManyBody().strength(-200))
      .force("center", d3.forceCenter(0, 0));

    // Tooltip
    const tooltip = d3.select("body").append("div")
        .attr("class", "d3-tooltip")
        .style("position", "absolute")
        .style("z-index", "10")
        .style("visibility", "hidden")
        .style("background", "rgba(17, 24, 39, 0.8)")
        .style("border", "1px solid #9333ea")
        .style("border-radius", "8px")
        .style("padding", "8px")
        .style("color", "#d1d5db")
        .style("font-size", "12px")
        .style("backdrop-filter", "blur(4px)");

    const link = svg.append("g")
      .attr("stroke", "#999")
      .attr("stroke-opacity", 0.6)
      .selectAll("line")
      .data(links)
      .join("line")
      .attr("stroke-width", 1.5);

    const node = svg.append("g")
      .selectAll("circle")
      .data(nodes)
      .join("circle")
      .attr("r", 10)
      .attr("fill", (d: Contact) => d.contactType === ContactType.PERSON ? "#60a5fa" : "#facc15") // blue for person, yellow for business
      .attr("stroke", "#ef4444")
      .attr("stroke-width", 2)
      .call(drag(simulation))
      .on("mouseover", (event: MouseEvent, d: any) => {
          tooltip.style("visibility", "visible").html(`<strong>${d.name}</strong><br/>${d.contactType}`);
      })
      .on("mousemove", (event: MouseEvent) => tooltip.style("top", (event.pageY - 10) + "px").style("left", (event.pageX + 10) + "px"))
      .on("mouseout", () => tooltip.style("visibility", "hidden"));

    const labels = svg.append("g")
      .selectAll("text")
      .data(nodes)
      .join("text")
      .text((d: any) => d.name)
      .attr("x", 12)
      .attr("y", 4)
      .style("font-size", "10px")
      .style("fill", "#e5e7eb")
      .style("pointer-events", "none")
      .style("text-shadow", "0 0 3px black");


    simulation.on("tick", () => {
      link
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y);

      node
        .attr("cx", (d: any) => d.x)
        .attr("cy", (d: any) => d.y);

      labels
        .attr("x", (d: any) => d.x + 12)
        .attr("y", (d: any) => d.y + 4);
    });

    function drag(simulation: any) {
      function dragstarted(event: any, d: any) {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
      }

      function dragged(event: any, d: any) {
        d.fx = event.x;
        d.fy = event.y;
      }

      function dragended(event: any, d: any) {
        if (!event.active) simulation.alphaTarget(0);
        d.fx = null;
        d.fy = null;
      }

      return d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended);
    }

    return () => {
        tooltip.remove();
    }
  }, [contacts, relationships]);
  
  if (contacts.length === 0 || relationships.length === 0) {
    return (
        <div className="flex items-center justify-center h-[400px] text-gray-400 text-center">
            <p>Add at least one contact and one relationship to view the network graph.</p>
        </div>
    );
  }

  return <svg ref={ref}></svg>;
};

export default ContactNetworkGraph;
