import React, { useMemo } from 'react';
import { Contact, Coordinates } from '../../types';
import NavigationMap from '../NavigationMap';
import { Icons } from '../Icons';

interface YellowSphereProps {
    contacts: Contact[];
    onViewManifesto: () => void;
}

const DEFAULT_CENTER: Coordinates = { latitude: 1.3521, longitude: 103.8198 }; // Singapore

const YellowSphere: React.FC<YellowSphereProps> = ({ contacts, onViewManifesto }) => {
    const mapMarkers = useMemo(() => {
        return contacts
            .filter(c => c.coordinates)
            .map(c => ({
                coords: c.coordinates!,
                popupText: `<b>${c.name}</b><br>${c.location || ''}`
            }));
    }, [contacts]);

    return (
        <div className="flex flex-col gap-6 p-4 h-full max-h-[75vh] pr-2">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-yellow-400">Yellow Sphere: Sea Navigation</h2>
                <button onClick={onViewManifesto} className="text-yellow-400 hover:text-white" title="View Sphere Manifesto">
                    <Icons.info className="w-6 h-6" />
                </button>
            </div>
            <div className="prophet-panel p-4 flex-grow flex flex-col">
                <p className="text-sm text-gray-400 mb-4 flex-shrink-0">Maritime operations chart. Monitor shipping lanes and naval assets.</p>
                <div className="flex-grow min-h-0 relative">
                    <NavigationMap 
                        center={DEFAULT_CENTER}
                        zoom={5}
                        markers={mapMarkers}
                        tileLayerUrl="https://tiles.stadiamaps.com/tiles/stamen_toner_background/{z}/{x}/{y}{r}.png"
                        tileLayerOptions={{
                            attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
                        }}
                    />
                    <div className="absolute bottom-4 right-4 z-[1000] bg-gray-900/80 backdrop-blur-sm p-3 rounded-lg border border-gray-600 text-xs text-gray-300 shadow-lg">
                        <h4 className="font-bold text-sm text-white mb-2">Legend</h4>
                        <ul className="space-y-2">
                            <li className="flex items-center gap-2">
                                <Icons.mapPin className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                                <span>Contact Location</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default YellowSphere;
