import React, { useState, useMemo } from 'react';
import { KnowledgeEntry, KnowledgeEntryType, ManifestoType } from '../../types';
import { Icons } from '../Icons';
import { useDebounce } from '../../hooks/useDebounce';
import SpherePanel from '../SpherePanel';

interface WhiteSphereProps {
  entries: KnowledgeEntry[];
  onAddEntry: (entry: Omit<KnowledgeEntry, 'id'>) => void;
  onViewEntry: (entry: KnowledgeEntry) => void;
  onToggleTask: (taskId: number) => void;
}

const fuzzyMatch = (term: string, text: string) => {
    const search = term.replace(/\s/g, '').toLowerCase();
    const target = text.replace(/\s/g, '').toLowerCase();
    let searchPosition = 0;
    for (let i = 0; i < target.length; i++) {
        if (target[i] === search[searchPosition]) {
            searchPosition++;
        }
        if (searchPosition === search.length) {
            return true;
        }
    }
    return false;
};

const WhiteSphere: React.FC<WhiteSphereProps> = ({ entries, onAddEntry, onViewEntry, onToggleTask }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tags, setTags] = useState('');
  const [entryType, setEntryType] = useState<KnowledgeEntryType>(KnowledgeEntryType.GENERAL);
  const [manifestoType, setManifestoType] = useState<ManifestoType>(ManifestoType.SHADOW);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  const [taskTitle, setTaskTitle] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [taskDueDate, setTaskDueDate] = useState('');
  const [taskTags, setTaskTags] = useState('');
  const [taskView, setTaskView] = useState<'active' | 'completed'>('active');

  const { manifestos, userEntries, tutorials, tasks } = useMemo(() => {
    const manifestos = entries.filter(e => e.entryType === KnowledgeEntryType.MANIFESTO);
    const tutorials = entries.filter(e => e.entryType === KnowledgeEntryType.TUTORIAL);
    const tasks = entries.filter(e => e.entryType === KnowledgeEntryType.TASK);
    const userEntries = entries.filter(e => ![KnowledgeEntryType.MANIFESTO, KnowledgeEntryType.TUTORIAL, KnowledgeEntryType.TASK].includes(e.entryType));
    return { manifestos, userEntries, tutorials, tasks };
  }, [entries]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      return alert('Please fill out all fields.');
    }
    const newEntry: Omit<KnowledgeEntry, 'id'> = {
        title,
        content,
        tags,
        entryType,
        ...(entryType === KnowledgeEntryType.MANIFESTO && { manifestoType })
    };
    onAddEntry(newEntry);
    setTitle('');
    setContent('');
    setTags('');
    setEntryType(KnowledgeEntryType.GENERAL);
  };

  const handleTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) {
        return alert('Please enter a task title.');
    }
    onAddEntry({
        title: taskTitle,
        content: taskDescription,
        tags: taskTags,
        entryType: KnowledgeEntryType.TASK,
        dueDate: taskDueDate,
        isCompleted: false,
    });
    setTaskTitle('');
    setTaskDescription('');
    setTaskDueDate('');
    setTaskTags('');
  };

  const filteredUserEntries = useMemo(() => {
    return [...userEntries].reverse().filter(entry => {
        if (!debouncedSearchTerm.trim()) return true;
        return (
            fuzzyMatch(debouncedSearchTerm, entry.title) ||
            fuzzyMatch(debouncedSearchTerm, entry.content) ||
            fuzzyMatch(debouncedSearchTerm, entry.tags)
        );
    });
  }, [userEntries, debouncedSearchTerm]);
  
  const filteredTasks = useMemo(() => {
    const sorted = tasks.sort((a, b) => new Date(a.dueDate || 0).getTime() - new Date(b.dueDate || 0).getTime());
    if (taskView === 'active') {
        return sorted.filter(t => !t.isCompleted);
    }
    return sorted.filter(t => t.isCompleted);
  }, [tasks, taskView]);

  return (
    <div className="flex flex-col gap-6 p-4 max-h-[75vh] overflow-y-auto pr-2">
      <h2 className="text-2xl font-bold text-blue-300">White Sphere: The Metaversity</h2>
      
      <SpherePanel title="Prophet's Orientation" icon={<Icons.bookOpen className="w-5 h-5"/>} titleColorClass="text-blue-300">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tutorials.map(t => (
                <button key={t.id} onClick={() => onViewEntry(t)} className="text-left bg-gray-900/70 p-4 rounded-md hover:bg-gray-700 transition-colors">
                    <h4 className="font-bold text-blue-300 flex items-center gap-2"><Icons.bookOpen className="w-5 h-5"/>{t.title.replace("Prophet's Orientation: ", "")}</h4>
                    <p className="text-xs text-gray-400 mt-1">{t.content.substring(0, 70)}...</p>
                </button>
            ))}
        </div>
      </SpherePanel>

      <SpherePanel title="Foundational Doctrines" icon={<Icons.manifesto className="w-5 h-5"/>} titleColorClass="text-blue-300">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {manifestos.map(m => (
                <button key={m.id} onClick={() => onViewEntry(m)} className="text-left bg-gray-900/70 p-4 rounded-md hover:bg-gray-700 transition-colors">
                    <h4 className="font-bold text-blue-300 flex items-center gap-2"><Icons.manifesto className="w-5 h-5"/>{m.title}</h4>
                    <p className="text-xs text-gray-400 mt-1">{m.content.substring(0, 70)}...</p>
                </button>
            ))}
        </div>
      </SpherePanel>

      <SpherePanel title="Task Directives" icon={<Icons.target className="w-5 h-5"/>} titleColorClass="text-blue-300">
        <details className="group mb-4">
            <summary className="cursor-pointer list-none flex items-center gap-1 font-medium group-hover:text-white text-sm text-gray-300">
                <span className="transition-transform duration-200 group-open:rotate-90"><Icons.arrowRight className="w-3 h-3"/></span>
                Create New Task Directive
            </summary>
            <form onSubmit={handleTaskSubmit} className="space-y-4 pt-4">
                <input type="text" placeholder="Task Title" value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
                <textarea placeholder="Description (Optional)" value={taskDescription} onChange={(e) => setTaskDescription(e.target.value)} rows={2} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus