import React, { useMemo } from 'react';
import { Contact, Coordinates } from '../../types';
import NavigationMap from '../NavigationMap';
import { Icons } from '../Icons';

interface RedSphereProps {
    contacts: Contact[];
    onViewManifesto: () => void;
}

const ESGENOOPETITJ_COORDS: Coordinates = { latitude: 47.2139, longitude: -65.1508 };

const RedSphere: React.FC<RedSphereProps> = ({ contacts, onViewManifesto }) => {
    const mapMarkers = useMemo(() => {
        const contactMarkers = contacts
            .filter(c => c.coordinates)
            .map(c => ({
                coords: c.coordinates!,
                popupText: `<b>${c.name}</b><br>${c.location || ''}`
            }));
        
        const baseMarker = {
            coords: ESGENOOPETITJ_COORDS,
            popupText: `<b>Base of Operations</b><br>Esgenoôpetitj First Nation`,
            isPermanent: true
        };

        return [baseMarker, ...contactMarkers];
    }, [contacts]);

    return (
        <div className="flex flex-col gap-6 p-4 h-full max-h-[75vh] pr-2">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-orange-400">Red Sphere: Land Navigation</h2>
                <button onClick={onViewManifesto} className="text-orange-400 hover:text-white" title="View Sphere Manifesto">
                    <Icons.info className="w-6 h-6" />
                </button>
            </div>
            <div className="prophet-panel p-4 flex-grow flex flex-col">
                <p className="text-sm text-gray-400 mb-4 flex-shrink-0">Tactical ground map. Primary operations centered at Esgenoôpetitj. All known contact locations are marked.</p>
                <div className="flex-grow min-h-0 relative">
                    <NavigationMap 
                        center={ESGENOOPETITJ_COORDS}
                        zoom={10}
                        markers={mapMarkers}
                        tileLayerUrl="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        tileLayerOptions={{
                            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        }}
                    />
                    <div className="absolute bottom-4 right-4 z-[1000] bg-gray-900/80 backdrop-blur-sm p-3 rounded-lg border border-gray-600 text-xs text-gray-300 w-48 shadow-lg">
                        <h4 className="font-bold text-sm text-white mb-2">Legend</h4>
                        <ul className="space-y-2">
                            <li className="flex items-center gap-2">
                                <Icons.base className="w-5 h-5 text-orange-400 flex-shrink-0" />
                                <span>Base of Operations</span>
                            </li>
                            <li className="flex items-center gap-2">
                                <Icons.mapPin className="w-5 h-5 text-gray-400 flex-shrink-0" />
                                <span>Contact Location</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RedSphere;
