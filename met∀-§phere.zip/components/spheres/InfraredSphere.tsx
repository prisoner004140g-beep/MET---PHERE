import React, { useState, useMemo } from 'react';
import { Contact, Relationship, ContactType, Sphere, RelationshipType, Coordinates, Persona } from '../../types';
import { Icons } from '../Icons';
import ContactNetworkGraph from '../ContactNetworkGraph';
import AddContactForm from '../AddContactForm';
import SpherePanel from '../SpherePanel';

interface InfraredSphereProps {
  contacts: Contact[];
  onAddContact: (contact: Omit<Contact, 'id' | 'coordinates'>) => Promise<{ geocodingSuccess: boolean }>;
  relationships: Relationship[];
  onAddRelationship: (relationship: Omit<Relationship, 'id'>) => void;
  onViewMap: (coords: Coordinates, name: string) => void;
  onAddPersona: (contactId: number, persona: Omit<Persona, 'id'>) => void;
  onViewContact: (contact: Contact) => void;
  onViewManifesto: () => void;
}

const AddPersonaForm: React.FC<{ contactId: number; onAddPersona: InfraredSphereProps['onAddPersona'] }> = ({ contactId, onAddPersona }) => {
    const [name, setName] = useState('');
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim() || !title.trim()) return alert('Persona name and title are required.');
        onAddPersona(contactId, { name, title, description });
        setName(''); setTitle(''); setDescription('');
    };

    return (
        <details className="group mt-3">
            <summary className="cursor-pointer text-xs font-medium text-gray-400 group-hover:text-white list-none flex items-center gap-1">
                <Icons.arrowRight className="w-3 h-3 transition-transform duration-200 group-open:rotate-90" /> Add Persona
            </summary>
            <form onSubmit={handleSubmit} className="mt-2 pl-4 space-y-2">
                <input type="text" placeholder="Persona Name (e.g., Red Shadow)" value={name} onChange={e => setName(e.target.value)} className="w-full bg-gray-700/50 border border-gray-600 rounded-md py-1 px-2 text-white text-xs"/>
                <input type="text" placeholder="Title (e.g., Drug Kingpin Investor)" value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-gray-700/50 border border-gray-600 rounded-md py-1 px-2 text-white text-xs"/>
                <textarea placeholder="Description..." value={description} onChange={e => setDescription(e.target.value)} rows={2} className="w-full bg-gray-700/50 border border-gray-600 rounded-md py-1 px-2 text-white text-xs"/>
                <button type="submit" className="w-full text-xs bg-red-800 hover:bg-red-700 text-white font-semibold py-1 px-2 rounded-md">Save Persona</button>
            </form>
        </details>
    );
};


const InfraredSphere: React.FC<InfraredSphereProps> = ({ contacts, onAddContact, relationships, onAddRelationship, onViewMap, onAddPersona, onViewContact, onViewManifesto }) => {
  // Form State
  const [sourceId, setSourceId] = useState<string>('');
  const [targetId, setTargetId] = useState<string>('');
  const [relationshipDesc, setRelationshipDesc] = useState('');
  const [relationshipSphere, setRelationshipSphere] = useState<Sphere>(Sphere.INFRARED);
  const [relationshipType, setRelationshipType] = useState<RelationshipType>(RelationshipType.ASSOCIATE);
  
  // Filter State
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [activeSphereFilter, setActiveSphereFilter] = useState<Sphere | null>(null);
  const [activePersona, setActivePersona] = useState<string | null>(null);

  const handleRelationshipSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sourceId || !targetId || !relationshipDesc.trim()) return alert('Please fill out all fields for the relationship.');
    if (sourceId === targetId) return alert('A contact cannot have a relationship with itself.');
    onAddRelationship({
      sourceId: parseInt(sourceId), targetId: parseInt(targetId),
      description: relationshipDesc, sphere: relationshipSphere, relationshipType: relationshipType
    });
    setSourceId(''); setTargetId(''); setRelationshipDesc('');
  };

  const getContactName = (id: number) => contacts.find(c => c.id === id)?.name || 'Unknown';

  const allTags = useMemo(() => Array.from(new Set(contacts.flatMap(c => c.tags?.split(',') || []).map(t => t.trim()).filter(Boolean))).sort(), [contacts]);
  const allSpheresInUse = useMemo(() => Array.from(new Set(relationships.map(r => r.sphere))).sort(), [relationships]);
  const allPersonas = useMemo(() => Array.from(new Set(contacts.flatMap(c => c.personas?.map(p => p.name) || []).filter(Boolean))).sort(), [contacts]);

  const filteredData = useMemo(() => {
    let filteredContacts = contacts;
    let filteredRelationships = relationships;

    if (activeTag) {
        const contactIdsWithTag = new Set(contacts.filter(c => c.tags?.split(',').some(tag => tag.trim() === activeTag)).map(c => c.id));
        filteredRelationships = relationships.filter(r => contactIdsWithTag.has(r.sourceId) || contactIdsWithTag.has(r.targetId));
        const relatedContactIds = new Set(filteredRelationships.flatMap(r => [r.sourceId, r.targetId]));
        filteredContacts = contacts.filter(c => relatedContactIds.has(c.id));
    }

    if (activeSphereFilter) {
        filteredRelationships = relationships.filter(r => r.sphere === activeSphereFilter);
        const relatedContactIds = new Set(filteredRelationships.flatMap(r => [r.sourceId, r.targetId]));
        filteredContacts = contacts.filter(c => relatedContactIds.has(c.id));
    }
    
    if (activePersona) {
        const contactIdsWithPersona = new Set(contacts.filter(c => c.personas?.some(p => p.name === activePersona)).map(c => c.id));
        filteredRelationships = relationships.filter(r => contactIdsWithPersona.has(r.sourceId) || contactIdsWithPersona.has(r.targetId));
        const relatedContactIds = new Set(filteredRelationships.flatMap(r => [r.sourceId, r.targetId]));
        filteredContacts = contacts.filter(c => relatedContactIds.has(c.id));
    }

    return { contacts: filteredContacts, relationships: filteredRelationships };
  }, [contacts, relationships, activeTag, activeSphereFilter, activePersona]);

  const relationshipTypeStyles: Record<RelationshipType, { icon: React.FC<any>, color: string }> = {
      [RelationshipType.FRIENDSHIP]: { icon: Icons.heart, color: 'text-pink-400' },
      [RelationshipType.CONFLICT]: { icon: Icons.zap, color: 'text-red-400' },
      [RelationshipType.NETWORKING]: { icon: Icons.share, color: 'text-green-400' },
      [RelationshipType.ASSOCIATE]: { icon: Icons.fileText, color: 'text-gray-400' },
  };

  return (
    <div className="flex flex-col gap-6 p-4 max-h-[75vh] overflow-y-auto pr-2">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-red-300">Infrared Sphere</h2>
        <button onClick={onViewManifesto} className="text-red-300 hover:text-white" title="View Sphere Manifesto">
            <Icons.info className="w-6 h-6" />
        </button>
      </div>
      
      <SpherePanel title="Add New Contact" icon={<Icons.user className="w-5 h-5" />} titleColorClass="text-red-300">
        <AddContactForm onAddContact={onAddContact} />
      </SpherePanel>

      <SpherePanel title="Define a Relationship" icon={<Icons.share className="w-5 h-5" />} titleColorClass="text-red-300">
          <form onSubmit={handleRelationshipSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                  <select value={sourceId} onChange={e => setSourceId(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm"><option value="">From...</option>{contacts.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
                  <select value={targetId} onChange={e => setTargetId(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm"><option value="">To...</option>{contacts.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
              </div>
              <input type="text" placeholder="Description (e.g., 'is CEO of')" value={relationshipDesc} onChange={e => setRelationshipDesc(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm"/>
              <div className="grid grid-cols-2 gap-4">
                <select value={relationshipType} onChange={e => setRelationshipType(e.target.value as RelationshipType)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm">{Object.values(RelationshipType).map(s => <option key={s} value={s}>{s}</option>)}</select>
                <select value={relationshipSphere} onChange={e => setRelationshipSphere(e.target.value as Sphere)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm">{Object.values(Sphere).map(s => <option key={s} value={s}>{s.split(' ')[0]}</option>)}</select>
              </div>
              <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 transform hover:scale-105 shadow-md">Add Relationship</button>
          </form>
      </SpherePanel>
      
      <SpherePanel title="Interaction Network" icon={<Icons.share className="w-5 h-5" />} titleColorClass="text-red-300">
        <ContactNetworkGraph contacts={filteredData.contacts} relationships={filteredData.relationships} />
      </SpherePanel>

      <SpherePanel title="Contacts & Relationships Catalog" icon={<Icons.users className="w-5 h-5" />} titleColorClass="text-red-300">
        <div className="mb-4 flex flex-wrap gap-2 border-b border-gray-700 pb-4">
            <button onClick={() => { setActiveTag(null); setActiveSphereFilter(null); setActivePersona(null); }} className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${!activeTag && !activeSphereFilter && !activePersona ? 'bg-red-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>All</button>
            {allTags.map(tag => <button key={tag} onClick={() => {setActiveTag(tag); setActiveSphereFilter(null); setActivePersona(null);}} className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${activeTag === tag ? 'bg-red-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>{tag}</button>)}
            {allSpheresInUse.map(sphere => <button key={sphere} onClick={() => {setActiveSphereFilter(sphere); setActiveTag(null); setActivePersona(null);}} className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${activeSphereFilter === sphere ? 'bg-purple-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>{sphere.split(' ')[0]}</button>)}
            {allPersonas.map(persona => <button key={persona} onClick={() => {setActivePersona(persona); setActiveTag(null); setActiveSphereFilter(null);}} className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${activePersona === persona ? 'bg-yellow-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>{persona}</button>)}
        </div>
        <div className="space-y-6">
            <div>
                <h4 className="text-lg font-semibold text-red-200 mb-2">Contacts</h4>
                {filteredData.contacts.length === 0 ? <p className="text-gray-400 text-center py-4">No contacts found.</p> : filteredData.contacts.map(contact => (
                    <div key={contact.id} className="bg-gray-900/70 p-4 rounded-md mb-3">
                        <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                                {contact.contactType === ContactType.PERSON ? <Icons.user className="w-5 h-5 text-blue-400"/> : <Icons.briefcase className="w-5 h-5 text-yellow-400"/>}
                                <div>
                                    <h5 className="font-bold text-lg text-red-300">{contact.name}</h5>
                                    <div className="flex items-center gap-4">
                                        {contact.location && <p className="text-xs text-gray-400 flex items-center gap-1"><Icons.mapPin className="w-3 h-3"/>{contact.location}</p>}
                                        {contact.language && <p className="text-xs text-gray-400 flex items-center gap-1"><Icons.messageCircle className="w-3 h-3"/>{contact.language}</p>}
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                {contact.coordinates && <button onClick={() => onViewMap(contact.coordinates!, contact.name)} className="text-xs bg-blue-600 hover:bg-blue-700 text-white font-semibold py-1 px-2 rounded-md">View Map</button>}
                                <button onClick={() => onViewContact(contact)} className="text-xs bg-purple-600 hover:bg-purple-700 text-white font-semibold py-1 px-2 rounded-md">Dossier</button>
                            </div>
                        </div>
                        {contact.notes && <p className="text-gray-300 whitespace-pre-wrap mt-2 pl-8 border-l-2 border-gray-700 text-sm">{contact.notes}</p>}
                        
                        <div className="mt-4 pl-8 space-y-2">
                           {contact.personas && contact.personas.length > 0 && contact.personas.map(p => (
                               <div key={p.id} className="bg-gray-800/50 p-2 rounded-md">
                                   <p className="font-bold text-sm text-red-200 flex items-center gap-2"><Icons.persona className="w-4 h-4"/>{p.name} <span className="font-normal text-xs text-gray-400">- {p.title}</span></p>
                                   <p className="text-xs text-gray-300 mt-1">{p.description}</p>
                               </div>
                           ))}
                           <AddPersonaForm contactId={contact.id} onAddPersona={onAddPersona} />
                        </div>

                        {contact.tags && (
                            <div className="mt-3 pl-8 flex flex-wrap gap-2">
                                {contact.tags.split(',').map(t => t.trim()).filter(Boolean).map(tag => <span key={tag} className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded-full">{tag}</span>)}
                            </div>
                        )}
                    </div>
                ))}
            </div>
             <div>
                <h4 className="text-lg font-semibold text-red-200 mb-2 mt-4">Relationships</h4>
                {filteredData.relationships.length === 0 ? <p className="text-gray-400 text-center py-4">No relationships found.</p> : filteredData.relationships.map(rel => {
                  const typeInfo = relationshipTypeStyles[rel.relationshipType];
                  const Icon = typeInfo.icon;
                  return (
                    <div key={rel.id} className="bg-gray-900/70 p-4 rounded-md mb-3">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 text-gray-200 text-sm">
                                <span className="font-bold text-blue-300">{getContactName(rel.sourceId)}</span>
                                <Icons.arrowRight className="w-4 h-4" />
                                <span className="font-bold text-blue-300">{getContactName(rel.targetId)}</span>
                            </div>
                             <div className="flex items-center gap-4">
                               <div className={`flex items-center gap-1.5 text-xs ${typeInfo.color}`}><Icon className="w-3.5 h-3.5" /><span>{rel.relationshipType}</span></div>
                               <span className="text-xs bg-purple-900/50 text-purple-300 px-2 py-1 rounded-full">{rel.sphere.split(' ')[0]}</span>
                            </div>
                        </div>
                        <p className="text-lg text-white mt-2 pl-2 border-l-2 border-gray-700">{rel.description}</p>
                    </div>
                  );
                })}
            </div>
        </div>
      </SpherePanel>
    </div>
  );
};

export default InfraredSphere;
