
import React from 'react';
import { Coordinates } from '../../types';
import NavigationMap from '../NavigationMap';
import { Icons } from '../Icons';
import L from 'leaflet';

interface MapMarker {
  coords: Coordinates;
  popupText: string;
  isPermanent?: boolean;
}

interface LegendItem {
    icon: React.FC<any>;
    label: string;
    colorClass: string;
}

interface NavigationSphereProps {
    title: string;
    description: string;
    center: Coordinates;
    zoom: number;
    markers: MapMarker[];
    tileLayerUrl: string;
    tileLayerOptions?: L.TileLayerOptions;
    color: 'orange' | 'cyan' | 'yellow';
    legendItems: LegendItem[];
    onViewManifesto: () => void;
}

const colorClasses = {
    orange: { text: 'text-orange-400' },
    cyan: { text: 'text-cyan-400' },
    yellow: { text: 'text-yellow-400' },
};

const NavigationSphere: React.FC<NavigationSphereProps> = ({ 
    title, description, center, zoom, markers, tileLayerUrl, tileLayerOptions, 
    color, legendItems, onViewManifesto 
}) => {
    const uiColors = colorClasses[color];

    return (
        <div className="flex flex-col gap-6 p-4 h-full max-h-[75vh] pr-2">
            <div className="flex justify-between items-center">
                <h2 className={`text-2xl font-bold ${uiColors.text}`}>{title}</h2>
                <button onClick={onViewManifesto} className={`${uiColors.text} hover:text-white`} title="View Sphere Manifesto">
                    <Icons.info className="w-6 h-6" />
                </button>
            </div>
            <div className="prophet-panel p-4 flex-grow flex flex-col">
                <p className="text-sm text-gray-400 mb-4 flex-shrink-0">{description}</p>
                <div className="flex-grow min-h-0 relative">
                    <NavigationMap 
                        center={center}
                        zoom={zoom}
                        markers={markers}
                        tileLayerUrl={tileLayerUrl}
                        tileLayerOptions={tileLayerOptions}
                    />
                    <div className="absolute bottom-4 right-4 z-[1000] bg-gray-900/80 backdrop-blur-sm p-3 rounded-lg border border-gray-600 text-xs text-gray-300 w-48 shadow-lg">
                        <h4 className="font-bold text-sm text-white mb-2">Legend</h4>
                        <ul className="space-y-2">
                            {legendItems.map(item => (
                                <li key={item.label} className="flex items-center gap-2">
                                    <item.icon className={`w-5 h-5 flex-shrink-0 ${item.colorClass}`} />
                                    <span>{item.label}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default NavigationSphere;