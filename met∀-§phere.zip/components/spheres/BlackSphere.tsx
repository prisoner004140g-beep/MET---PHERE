import React, { useState, useMemo } from 'react';
import { ThoughtEntry } from '../../types';
import { Icons } from '../Icons';
import MoodChart from '../MoodChart';
import SpherePanel from '../SpherePanel';

interface BlackSphereProps {
  entries: ThoughtEntry[];
  onAddEntry: (entry: Omit<ThoughtEntry, 'id' | 'timestamp'>) => void;
  onViewManifesto: () => void;
}

const BlackSphere: React.FC<BlackSphereProps> = ({ entries, onAddEntry, onViewManifesto }) => {
  const [content, setContent] = useState('');
  const [mood, setMood] = useState('Reflection');
  const [tags, setTags] = useState('');
  const moods = ['Reflection', 'Idea', 'Mood', 'Task', 'Dream', 'Note'];
  const [activeMoodFilter, setActiveMoodFilter] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      return alert('Please write something.');
    }
    onAddEntry({ content, mood, tags });
    setContent('');
    setTags('');
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const filteredEntries = useMemo(() => {
    if (!activeMoodFilter) {
      return [...entries].reverse();
    }
    return [...entries].reverse().filter(entry => entry.mood === activeMoodFilter);
  }, [entries, activeMoodFilter]);

  return (
    <div className="flex flex-col gap-6 p-4 max-h-[75vh] overflow-y-auto pr-2">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-300">Black Sphere</h2>
        <button onClick={onViewManifesto} className="text-gray-300 hover:text-white" title="View Sphere Manifesto">
            <Icons.info className="w-6 h-6" />
        </button>
      </div>
      
      <SpherePanel title="Mood Analysis" icon={<Icons.brain className="w-5 h-5"/>} titleColorClass="text-gray-300">
        <MoodChart entries={entries} />
      </SpherePanel>

      <SpherePanel title="Log a Thought" icon={<Icons.messageCircle className="w-6 h-6" />} titleColorClass="text-gray-300">
        <form onSubmit={handleSubmit} className="space-y-4">
          <textarea placeholder="What's on your mind, Prophet?" value={content} onChange={(e) => setContent(e.target.value)} rows={4} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm"/>
          <input type="text" placeholder="Tags (e.g., project-alpha, weekly-review)" value={tags} onChange={(e) => setTags(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm"/>
          <div className="flex items-center gap-4">
            <label htmlFor="mood-select" className="text-sm font-medium text-gray-300">Category:</label>
            <select id="mood-select" value={mood} onChange={(e) => setMood(e.target.value)} className="flex-grow bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm">
                {moods.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <button type="submit" className="w-full bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 transform hover:scale-105 shadow-md">Record Entry</button>
        </form>
      </SpherePanel>

      <SpherePanel title="Thought Stream" icon={<Icons.messageCircle className="w-5 h-5"/>} titleColorClass="text-gray-300" className="flex-grow flex flex-col">
        <div className="mb-4 flex flex-wrap gap-2 border-b border-gray-700 pb-4">
            <button onClick={() => setActiveMoodFilter(null)} className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${!activeMoodFilter ? 'bg-gray-500 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>All</button>
            {moods.map(m => (
                <button key={m} onClick={() => setActiveMoodFilter(m)} className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${activeMoodFilter === m ? 'bg-gray-500 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>{m}</button>
            ))}
        </div>
        <div className="space-y-4 flex-grow overflow-y-auto pr-2">
          {filteredEntries.length === 0 ? (
            <p className="text-gray-400 text-center py-4">No thoughts recorded for this category.</p>
          ) : (
            filteredEntries.map(entry => (
              <div key={entry.id} className="bg-gray-900/70 p-4 rounded-md border-l-4 border-gray-600">
                <div className="flex justify-between items-center text-xs text-gray-400 mb-2">
                    <span>{formatDate(entry.timestamp)}</span>
                    <span className="font-semibold bg-gray-700 px-2 py-1 rounded-full">{entry.mood}</span>
                </div>
                <p className="text-gray-200 whitespace-pre-wrap">{entry.content}</p>
                 {entry.tags && (
                    <div className="mt-3 flex flex-wrap gap-2">
                        {entry.tags.split(',').map(tag => tag.trim()).filter(Boolean).map((tag, index) => (
                            <span key={index} className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded-full">{tag}</span>
                        ))}
                    </div>
                )}
              </div>
            ))
          )}
        </div>
      </SpherePanel>
    </div>
  );
};

export default BlackSphere;
