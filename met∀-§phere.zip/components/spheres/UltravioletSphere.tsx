import React, { useMemo } from 'react';
import { Transaction, TransactionType } from '../../types';
import FinancialSummary from '../FinancialSummary';
import FinancialInputForm from '../FinancialInputForm';
import TransactionList from '../TransactionList';
import TransactionChart from '../TransactionChart';
import { Icons } from '../Icons';
import SpherePanel from '../SpherePanel';

interface UltravioletSphereProps {
    transactions: Transaction[];
    onAddTransaction: (transaction: Omit<Transaction, 'id' | 'date'>) => void;
    onViewManifesto: () => void;
}

const UltravioletSphere: React.FC<UltravioletSphereProps> = ({ transactions, onAddTransaction, onViewManifesto }) => {
    const { totalIncome, totalExpenses, balance } = useMemo(() => {
        const income = transactions
          .filter(t => t.type === TransactionType.INCOME)
          .reduce((sum, t) => sum + t.amount, 0);
        const expenses = transactions
          .filter(t => t.type === TransactionType.EXPENSE)
          .reduce((sum, t) => sum + t.amount, 0);
        return { totalIncome: income, totalExpenses: expenses, balance: income - expenses };
      }, [transactions]);

    return (
        <div className="flex flex-col gap-6 p-4 h-full max-h-[75vh] overflow-y-auto pr-2">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-purple-300">Ultraviolet Sphere</h2>
                <button onClick={onViewManifesto} className="text-purple-300 hover:text-white" title="View Sphere Manifesto">
                    <Icons.info className="w-6 h-6" />
                </button>
            </div>
            <SpherePanel title="Financial Overview" icon={<Icons.balance className="w-5 h-5"/>} titleColorClass="text-purple-300">
                <FinancialSummary totalIncome={totalIncome} totalExpenses={totalExpenses} balance={balance} />
            </SpherePanel>
            <SpherePanel title="Transaction History" icon={<Icons.income className="w-5 h-5"/>} titleColorClass="text-purple-300">
                <TransactionChart transactions={transactions} />
            </SpherePanel>
            <SpherePanel title="Add New Transaction" icon={<Icons.arrowUp className="w-5 h-5"/>} titleColorClass="text-purple-300">
                <FinancialInputForm onAddTransaction={onAddTransaction} />
            </SpherePanel>
            <SpherePanel title="Recent Transactions" icon={<Icons.arrowDown className="w-5 h-5"/>} titleColorClass="text-purple-300">
                <TransactionList transactions={transactions} />
            </SpherePanel>
        </div>
    );
};

export default UltravioletSphere;
