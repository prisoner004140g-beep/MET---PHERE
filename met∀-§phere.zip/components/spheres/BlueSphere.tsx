import React, { useMemo } from 'react';
import { Contact, Coordinates } from '../../types';
import NavigationMap from '../NavigationMap';
import { Icons } from '../Icons';

interface BlueSphereProps {
    contacts: Contact[];
    onViewManifesto: () => void;
}

const DEFAULT_CENTER: Coordinates = { latitude: 20, longitude: 0 };

const BlueSphere: React.FC<BlueSphereProps> = ({ contacts, onViewManifesto }) => {
    const mapMarkers = useMemo(() => {
        return contacts
            .filter(c => c.coordinates)
            .map(c => ({
                coords: c.coordinates!,
                popupText: `<b>${c.name}</b><br>${c.location || ''}`
            }));
    }, [contacts]);

    return (
        <div className="flex flex-col gap-6 p-4 h-full max-h-[75vh] pr-2">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-cyan-400">Blue Sphere: Air Navigation</h2>
                <button onClick={onViewManifesto} className="text-cyan-400 hover:text-white" title="View Sphere Manifesto">
                    <Icons.info className="w-6 h-6" />
                </button>
            </div>
            <div className="prophet-panel p-4 flex-grow flex flex-col">
                 <p className="text-sm text-gray-400 mb-4 flex-shrink-0">Global aerospace overview. Use for flight path planning and aerial reconnaissance.</p>
                <div className="flex-grow min-h-0 relative">
                    <NavigationMap 
                        center={DEFAULT_CENTER}
                        zoom={2}
                        markers={mapMarkers}
                        tileLayerUrl="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                        tileLayerOptions={{
                            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
                        }}
                    />
                     <div className="absolute bottom-4 right-4 z-[1000] bg-gray-900/80 backdrop-blur-sm p-3 rounded-lg border border-gray-600 text-xs text-gray-300 shadow-lg">
                        <h4 className="font-bold text-sm text-white mb-2">Legend</h4>
                        <ul className="space-y-2">
                            <li className="flex items-center gap-2">
                                <Icons.mapPin className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                                <span>Contact Location</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BlueSphere;
