import React, { useState } from 'react';
import { Contact, ContactType } from '../types';
import { Icons } from './Icons';

interface AddContactFormProps {
  onAddContact: (contact: Omit<Contact, 'id' | 'coordinates'>) => Promise<{ geocodingSuccess: boolean }>;
}

const DetailsSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <details className="group">
      <summary className="cursor-pointer text-sm font-medium text-gray-400 group-hover:text-white list-none">
        <div className="flex items-center"><span className="transition-transform duration-200 group-open:rotate-90"><Icons.arrowRight className="w-4 h-4" /></span><span className="ml-2">{title}</span></div>
      </summary>
      <div className="pt-2 pl-6">{children}</div>
    </details>
);

const AddContactForm: React.FC<AddContactFormProps> = ({ onAddContact }) => {
  const [name, setName] = useState('');
  const [notes, setNotes] = useState('');
  const [contactType, setContactType] = useState<ContactType>(ContactType.PERSON);
  const [location, setLocation] = useState('');
  const [hobbies, setHobbies] = useState('');
  const [skills, setSkills] = useState('');
  const [knowledge, setKnowledge] = useState('');
  const [debts, setDebts] = useState('');
  const [credits, setCredits] = useState('');
  const [tags, setTags] = useState('');
  const [language, setLanguage] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [geocodingError, setGeocodingError] = useState<string | null>(null);

  const resetForm = () => {
    setName(''); setNotes(''); setLocation(''); setHobbies(''); setSkills('');
    setKnowledge(''); setDebts(''); setCredits(''); setTags(''); setLanguage('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    if (!trimmedName) return alert('Please enter a name.');
    
    setIsLoading(true);
    setGeocodingError(null);
    const wasLocationProvided = location.trim() !== '';

    try {
        const { geocodingSuccess } = await onAddContact({ 
            name: trimmedName, notes, contactType, location, hobbies, skills, knowledge, debts, credits, tags, language 
        });
        resetForm();
        
        if (!geocodingSuccess && wasLocationProvided) {
            setGeocodingError(`Warning: Location for "${trimmedName}" could not be found. The contact was saved without coordinates.`);
        }
    } catch (error) {
        console.error("Failed to add contact:", error);
        alert("An unexpected error occurred while saving the contact.");
    } finally {
        setIsLoading(false);
    }
  };

  const handleInputChange = <T extends string | ContactType>(setter: React.Dispatch<React.SetStateAction<T>>) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setter(e.target.value as T);
    if (geocodingError) setGeocodingError(null);
  };

  return (
    <>
      {geocodingError && (
          <div className="bg-yellow-900/30 border border-yellow-500 text-yellow-300 text-sm p-3 rounded-md mb-4 flex justify-between items-center">
              <span>{geocodingError}</span>
              <button onClick={() => setGeocodingError(null)} className="text-yellow-300 hover:text-white">
                  <Icons.close className="w-4 h-4" />
              </button>
          </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                  <label className="block text-sm font-medium text-gray-300">Name</label>
                  <input type="text" value={name} onChange={handleInputChange(setName)} className="mt-1 block w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm"/>
              </div>
              <div>
                  <label className="block text-sm font-medium text-gray-300">Type</label>
                  <select value={contactType} onChange={handleInputChange(setContactType)} className="mt-1 block w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm">
                      {Object.values(ContactType).map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
              </div>
          </div>
        <textarea placeholder="Notes / Profile..." value={notes} onChange={handleInputChange(setNotes)} rows={2} className="mt-1 block w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm"/>
        <input type="text" placeholder="Location (e.g., 123 Main St, Anytown)" value={location} onChange={handleInputChange(setLocation)} className="mt-1 block w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm"/>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="text" placeholder="Tags (comma-separated, e.g., work, project-x)" value={tags} onChange={handleInputChange(setTags)} className="block w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm"/>
            <input type="text" placeholder="Language(s) (e.g., English, PIE)" value={language} onChange={handleInputChange(setLanguage)} className="block w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm"/>
        </div>

        <div className="space-y-2 border-t border-gray-700 pt-4">
          <DetailsSection title="Personal Details"><textarea placeholder="Hobbies, interests..." value={hobbies} onChange={handleInputChange(setHobbies)} className="mt-1 block w-full bg-gray-900/50 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm text-xs" /></DetailsSection>
          <DetailsSection title="Professional Details"><div className="space-y-2"><textarea placeholder="Skills, experience..." value={skills} onChange={handleInputChange(setSkills)} className="mt-1 block w-full bg-gray-900/50 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm text-xs" /><textarea placeholder="Knowledge areas..." value={knowledge} onChange={handleInputChange(setKnowledge)} className="mt-1 block w-full bg-gray-900/50 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm text-xs" /></div></DetailsSection>
          <DetailsSection title="Financial Details"><div className="space-y-2"><textarea placeholder="Debts (e.g., Owes me $50 for lunch)" value={debts} onChange={handleInputChange(setDebts)} className="mt-1 block w-full bg-gray-900/50 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm text-xs" /><textarea placeholder="Credits (e.g., I owe $20 for coffee)" value={credits} onChange={handleInputChange(setCredits)} className="mt-1 block w-full bg-gray-900/50 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm text-xs" /></div></DetailsSection>
        </div>
        <button type="submit" disabled={isLoading} className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 transform hover:scale-105 shadow-md disabled:bg-gray-600 disabled:scale-100 disabled:cursor-wait">
          {isLoading ? (
              <span className="flex items-center justify-center">
                  <Icons.spinner className="animate-spin w-5 h-5 mr-2" /> Adding...
              </span>
          ) : 'Add Contact'}
        </button>
      </form>
    </>
  );
};

export default AddContactForm;
