

import React from 'react';
import { Directive, Sphere } from '../types';
import { Icons } from './Icons';

interface DirectivesProps {
  directive: Directive | null;
  onRequestDirective: (sphere: Sphere) => void;
  onCompleteDirective: () => void;
  isLoading: boolean;
  error: string | null;
  activeSphere: Sphere;
}

const Directives: React.FC<DirectivesProps> = ({ directive, onRequestDirective, onCompleteDirective, isLoading, error, activeSphere }) => {
  const sphereColorClasses: Record<string, string> = {
      'Ultraviolet (Finance)': 'border-purple-500 text-purple-300',
      'Infrared (Interactions)': 'border-red-500 text-red-300',
      'White (Learning)': 'border-blue-500 text-blue-300',
      'Black (Thoughts)': 'border-gray-500 text-gray-300',
      'Red (Land Navigation)': 'border-orange-500 text-orange-300',
      'Blue (Air Navigation)': 'border-cyan-500 text-cyan-300',
      'Yellow (Sea Navigation)': 'border-yellow-500 text-yellow-300',
  };

  return (
    <div className="prophet-panel p-4">
      <h2 className="text-lg font-semibold mb-3 text-purple-300 flex items-center gap-2">
        <Icons.target className="w-5 h-5"/>
        Prophet's Directives
      </h2>
      {directive ? (
        <div className={`p-4 rounded-md bg-gray-900/50 border-l-4 ${sphereColorClasses[directive.sphere] || 'border-gray-500'}`}>
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-bold text-white">{directive.title}</h3>
              <p className="text-xs font-medium text-gray-400 mt-1">Sphere: <span className={sphereColorClasses[directive.sphere]}>{directive.sphere.split(' ')[0]}</span></p>
            </div>
            <button onClick={onCompleteDirective} className="text-xs bg-red-800 hover:bg-red-700 text-white font-semibold py-1 px-2 rounded-md flex-shrink-0 ml-2">Dismiss</button>
          </div>
          <p className="text-sm text-gray-300 mt-3 italic">"{directive.description}"</p>
          
          <div className="mt-4 border-t border-gray-700 pt-3">
            <p className="text-xs font-bold text-purple-300 mb-1">RATIONALE:</p>
            <p className="text-sm text-gray-200">{directive.rationale}</p>
          </div>

          <div className="mt-4">
            <p className="text-xs font-bold text-purple-300 mb-2">OBJECTIVE:</p>
            <p className="text-sm font-semibold text-white bg-gray-900 p-2 rounded-md">{directive.objective}</p>
          </div>

          <div className="mt-4">
            <p className="text-xs font-bold text-purple-300 mb-2">ACTIONABLE STEPS:</p>
            <ul className="space-y-2">
                {directive.steps.map((step, index) => (
                    <li key={index} className="text-sm text-gray-200 flex items-start gap-2">
                        <span className="text-purple-400 font-bold">{index + 1}.</span>
                        <span>{step}</span>
                    </li>
                ))}
            </ul>
          </div>

           <button onClick={onCompleteDirective} className="w-full mt-6 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg text-sm">
             Mark as Complete
           </button>
        </div>
      ) : (
        <div className="text-center py-4">
          <p className="text-gray-400 mb-4">No active directive. The simulation awaits your move, Prophet.</p>
          <button 
            onClick={() => onRequestDirective(activeSphere)}
            className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 transform hover:scale-105 shadow-md inline-flex items-center justify-center disabled:bg-gray-600 disabled:scale-100 disabled:cursor-wait"
            disabled={isLoading}
          >
            {isLoading && <Icons.spinner className="animate-spin w-5 h-5 mr-2" />}
            {isLoading ? 'Generating...' : `Request ${activeSphere.split(' ')[0]} Directive`}
          </button>
          {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
        </div>
      )}
    </div>
  );
};

export default Directives;